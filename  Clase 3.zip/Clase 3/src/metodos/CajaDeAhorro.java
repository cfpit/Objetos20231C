
package metodos;

public class CajaDeAhorro {
    //atributos
    public long saldo;
    public String moneda;
    
    //constructores
    public CajaDeAhorro() {}
    
    //metodos
    public void consultarSaldo() {
        System.out.println("saldo = " + this.saldo + " " + this.moneda);
    }
    
    public void depositar(int monto) {
        this.saldo += monto;
    }
    
    public String extraer(int monto) {
        if (monto < this.saldo) {
            this.saldo -= monto;
            return "Extraccion OK!!";
        } else {
            return "Fondos Insuficientes";
        }
    }
    
    
    
    
}





