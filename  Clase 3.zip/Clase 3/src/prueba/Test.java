

package prueba;

import java.util.Scanner;
import metodos.CajaDeAhorro;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);

        //creo una caja de ahorro(o sea, un objeto de la clase CajaDeAhorro)
        CajaDeAhorro cda = new CajaDeAhorro();
                                                    
        //inicializo el estado de la caja
        System.out.println("Cual es el saldo inicial?: ");
        cda.saldo = lector.nextInt();
        
        System.out.println("Cual es la moneda de la caja?: ");
        cda.moneda = lector.next();
        
        //informo el saldo de la caja
        cda.consultarSaldo();
        
        //deposito
        System.out.println("Indique el monto a depositar: ");
        cda.depositar(lector.nextInt());
        
        //informo el nuevo saldo de la caja
        System.out.println("Nuevo saldo: ");
        cda.consultarSaldo();
        
        //extraccion
        System.out.println("Indique el monto a extraer: ");
        System.out.println(cda.extraer(lector.nextInt()));
        
        //informo el nuevo saldo de la caja
        System.out.println("Nuevo saldo: ");
        cda.consultarSaldo();
    
    }
}
