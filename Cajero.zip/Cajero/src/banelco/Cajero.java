package banelco;

public class Cajero {
    //atributos
    public int saldo;
    public String moneda;
    
    //constructores
    public Cajero() {}
    
    //metodos
    public String consultarSaldo() {
        return "saldo = " + this.saldo;
    }
    
    public void depositar(int monto) {
        this.saldo += monto;
    }
    
    public String extraer(int monto) {
        if (this.saldo >= monto) {
            this.saldo -= monto;
            return "Extraccion OK!!";
        } else {
            return "Fondos Insuficientes";
        }
    }

    @Override
    public String toString() {
        return "saldo=" + saldo + ", moneda=" + moneda;
    }
}
