
package abstractas;

public class Avion extends Vehiculo{
    
    //atributos
    private int asientos;
    
    //constructores
    public Avion() {}

    public Avion(int asientos, String color, int velocidad) {
        //llamada la constructor del padre(Vehiculo)
        super(color, velocidad);
        
        this.setAsientos(asientos);
    }
    
    //getters y setters
    public int getAsientos() {
        return asientos;
    }

    public void setAsientos(int asientos) {
        this.asientos = asientos;
    }
    
    //metodos
    //implemento el metodo abstacto acelerar del padre(Vehiculo)
    @Override
    public void acelerar() {
        this.velocidad += 100;
    }
    
    
    @Override
    public String toString() {
        return super.toString() + " asientos=" + asientos;
    }
}
