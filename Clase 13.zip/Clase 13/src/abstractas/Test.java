
package abstractas;

public class Test {
    public static void main(String[] args) {
        //intento crear un objeto de la clase Vehiculo
        //no puedo por ser abstracta
//        Vehiculo v = new Vehiculo();
        
        //creo un avion y una bici
        Avion a = new Avion(100, "blanco", 0);
        Bici b = new Bici(28, "negro", 0);
        
        //comportamiento
        a.acelerar();//0 -> 100
        b.acelerar();//0 -> 5
        
        //estado 
        System.out.println("Avion: \n" + a);
        System.out.println("Bici: \n" + b);
    }
}
