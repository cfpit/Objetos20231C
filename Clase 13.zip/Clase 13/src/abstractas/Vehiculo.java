
package abstractas;

public abstract class Vehiculo {
    //atributos
    private String color;
    protected int velocidad;
    
    //constructores
    public Vehiculo() {}

    public Vehiculo(String color, int velocidad) {
        this.setColor(color);
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    //metodos
    
    //metodos abstractos
    //Se define la firma sin cuerpo.
    //Las clases hijas DEBEN implementar el cuerpo de todos los 
    //metodos abstractos del padre.
    //Me indica QUE van a hacer las clases hijas
    //pero no el COMO lo van a hacer
    public abstract void acelerar();
    
    //metodos concretos
    @Override
    public String toString() {
        return "color=" + color + ", velocidad=" + velocidad;
    }
}
