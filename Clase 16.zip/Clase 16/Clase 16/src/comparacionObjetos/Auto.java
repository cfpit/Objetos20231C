package comparacionObjetos;

//comparacion objetos2

import java.util.Objects;


/**
 *
 * @author Jorge Sanchez
 */
public class Auto {

    //atributos
    private int nroMotor;
    
    //constructores
    public Auto() {}
    
    public Auto(int NroMotor){
        this.setNroMotor(NroMotor);
    }

    //getters y setters
    public int getNroMotor() {
        return nroMotor;
    }
    
    public void setNroMotor(int nroMotor) {
        this.nroMotor = nroMotor;
    }
    
    //Metodos
    // redefino el metodo equals presente en clase Object
//    public boolean equals( Object x )
//    {
//        Auto a = (Auto) x; // casteo referencia
//        
//        if( this.getNroMotor() == a.getNroMotor() )
//        {
//            return true;
//        }
//        
//        return false;
//    }

    

    @Override
    public boolean equals(Object obj) {
        Auto a = (Auto) obj;
        
        if (this.getNroMotor() == a.getNroMotor()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(nroMotor);
    }
    

    @Override
    public String toString() {
        return "Auto{" + "nroMotor=" + nroMotor + '}';
    }
}
