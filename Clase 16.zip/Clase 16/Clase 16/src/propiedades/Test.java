
package propiedades;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        
        String cliente = new String("Juan Perez");//referenciado
        String cliente2 = new String("Juan Perez");//referenciado
        
        cliente = cliente2;//copia de objetos
        
        new String("Maria Garcia");//anonimo o sin referencia
        new String("Luis Gonzalez");
        
        //creo una coleccion
        ArrayList losClientes = new ArrayList();
        
        //agrego objetos a la coleccion
        losClientes.add(cliente);
        losClientes.add(new String("Maria Garcia"));
        losClientes.add(new String("Luis Gonzalez"));
        
        //veo el contenido de la coleccion
        System.out.println(losClientes);
        
        int [] edades = new int [20];//80 bytes
        
        System.gc();//llamo al recolector de basura(Garbage collector)
        
        System.out.println("Propiedades del sistema: ");
        System.out.println(System.getProperties());
        
        System.out.println("------------------------");
        
        System.out.println("Version de Java: " + System.getProperty("java.version"));
        System.out.println("Nombre del S.O.: " + System.getProperty("os.name"));
        System.out.println("Version del S.O.: " + System.getProperty("os.version"));
        
        
    }
}
