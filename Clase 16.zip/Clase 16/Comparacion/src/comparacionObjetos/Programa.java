package comparacionObjetos;

/**
 *
 * @author Jorge Sanchez
 */
public class Programa {

    public static void main(String[] args) {

        //Comparación entre objetos
        // El == con objetos, no compara contenido sino referencias,
        // por este motivo no entra al if:

//        Auto a1 = new Auto(456); //123 es el numero de motor
//        Auto a2 = new Auto(123);
////        a1 = a2;//igualo las referencias
//
//        if( a1 == a2) 
//        {
//            System.out.println("Igual referencia");
//        }
//        else
//        {
//            System.out.println("Diferente referencia");
//        }

//        System.out.println(a1.hashCode());
//        System.out.println(a2.hashCode());

        // • El método equals(), compara el contenido de objetos,
        // no entra al if hasta que no redefinimos el metodo equals()):

        Auto a1 = new Auto(123);
        Auto a2 = new Auto(123);
        
        if (a1.equals(a2)) 
        {
            System.out.println("Igual contenido");
        }
        
        else
        {
            System.out.println("Diferente contenido");
        }

        System.out.println(a1.hashCode());
        System.out.println(a2.hashCode());

    }

}
