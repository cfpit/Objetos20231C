/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package propiedades;

/**
 *
 * @author Jorge Sanchez
 */
public class Programa {
    public static void main(String[] args) {
        
        System.out.print("Propiedades del Sistema: ");    
        System.out.println(System.getProperties());
        
        System.out.println("----------------------------");
        
        System.out.print("Version de Java: ");
        System.out.println(System.getProperty("java.version"));
        
        System.out.print("Nombre del S.O.: ");
        System.out.println(System.getProperty("os.name"));
        
        System.out.print("Version del S.O.: ");
        System.out.println(System.getProperty("os.version"));
        
        //llamada al garbage collector
        System.gc();
    }
}
