package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo cola (FIFO)
        Queue<String> cola = new LinkedList<>();
        
        //agrego objetos en la cola
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Ana");
        cola.add("Luis");
        
        System.out.println("Contenido de la cola: " + cola);
        
        if (cola.contains("Luis")) 
        {
            System.out.println("Si esta en la coleccion");
        } 
        else 
        {
            System.out.println("No esta en la coleccion");
        }
        
        System.out.println("Proximo elemento a salir de la cola: " + cola.peek());
        
        System.out.println("Saco un elemento: " + cola.poll());
        
        System.out.println("Nuevo contenido de la cola: " + cola);
    
    
    }
}
