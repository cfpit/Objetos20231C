package colecciones.listas;

import java.util.ArrayList;
import java.util.Iterator;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo lista
        ArrayList<Persona> personas = new ArrayList<>();
        
        //creo objetos con referencia
        Persona p1 = new Persona("Juan Perez", 25);
        Persona p2 = new Persona("Maria Garcia", 30);
        Persona p3 = new Persona("Luis Gonzalez", 18);
        Persona p4 = new Persona("Ana Lopez", 40);
        
        //agrego los objetos en la coleccion
        personas.add(p1);
        personas.add(p2);
        personas.add(p3);
        personas.add(p4);
        
        System.out.println("Contenido de la coleccion: " + personas);
        
        System.out.println("Recorro la coleccion: ");
        
        /*
            forl --> recorro con for
            fore --> recorro con foreach
            whileit --> recorro con iterator(patron de diseño)
        */
        
        System.out.println("con for");
        for (int i = 0; i < personas.size(); i++) {
            Persona unaPersona = personas.get(i);
            System.out.println(unaPersona);
        }
        
        System.out.println("-----------------------");
        
        System.out.println("con foreach");
        for (Persona unaPersona : personas) {
            System.out.println(unaPersona);
        }
        
        System.out.println("-----------------------");
        
        System.out.println("con iterator");
        
        //creo un iterador para recorrer la coleccion
       Iterator it = personas.iterator();
        
       //recorro la coleccion y muestro su contenido
        while (it.hasNext()) {
            Persona unaPersona = (Persona)it.next();
            if (unaPersona.getEdad() >= 30) {
                System.out.println(unaPersona);
            }
        }
    }
}
