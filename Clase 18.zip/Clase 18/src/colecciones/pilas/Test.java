package colecciones.pilas;

import java.util.Stack;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo pila(Stack)
//        Stack pila = new Stack();//no tipada
        Stack<Integer> pila = new Stack<>();//coleccion tipada
        
        //agrego objetos de la clase String e Integer
        //en la pila
//        pila.push("Juan");
//        pila.push("Maria");
//        pila.push("Ana");
//        pila.push("Luis");
        pila.push(25);
        pila.push(30);
        pila.push(18);
        pila.push(40);
        
        
        System.out.println("Contenido de la pila: " + pila);
        
        System.out.println("Tamaño de la pila: " + pila.size());
        
        System.out.println("Valor en posicion 2: " + pila.get(2));
        
        System.out.println("Elimino objeto en posicion 2: " + pila.remove(2));
        
        System.out.println("Nuevo contenido de la pila: " + pila);
        
        System.out.println("Proximo elemento a salir de la pila: " + pila.peek());
        
        System.out.println("Saco un elemento: " + pila.pop());
        
        if (pila.empty()) 
        {
            System.out.println("pila vacia");
        } 
        else 
        {
            System.out.println("pila NO vacia");
        }
        
        System.out.println("saco todos los objetos de la pila");
        pila.removeAllElements();
        
        System.out.println("Contenido de la pila: " + pila);
        
        
        
        
    
    
    }
}
