package colecciones.generics;

import java.util.ArrayList;

public class Generica<T> {
    //atributos
    ArrayList<T> miLista = new ArrayList<>();
    
    //metodos delegados
    //Son metodos q llaman a otros metodos de otros objetos

    public boolean agregar(T e) {
        return miLista.add(e);
    }

    public boolean eliminar(Object o) {
        return miLista.remove(o);
    }
    
    public void listar() {
        System.out.println(miLista);
    }
}
