package colecciones.generics;

public class Test {
    public static void main(String[] args) {
        //creo un objeto de tipo clase generica
        Generica<String> lista = new Generica<>();
        Generica<Integer> lista2 = new Generica<>();
        Generica<Persona> lista3 = new Generica<>();
        
        lista.agregar("Juan");
        lista.agregar("Maria");
        lista.agregar("Luis");
        lista.agregar("Ana");
        
        lista.eliminar("Luis");
        
        lista.listar();
        
        System.out.println("--------------------");
        
        lista2.agregar(25);
        lista2.agregar(30);
        lista2.agregar(20);
        lista2.agregar(40);
        
        lista2.eliminar(20);
        
        lista2.listar();
        
        System.out.println("--------------------");
        
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Luis", 20);
        
        
        lista3.agregar(p1);
        lista3.agregar(p2);
        lista3.agregar(p3);
        lista3.agregar(new Persona("Ana", 40));
        
        lista3.eliminar(p3);
        lista3.eliminar(new Persona("Ana", 40));
        
        lista3.listar();
        
        
    }
}
