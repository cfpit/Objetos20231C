package colecciones.mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;


public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo mapa
//        HashMap<String,String> diccionario = new HashMap<>();//desordenado
//        LinkedHashMap<String,String> diccionario = new LinkedHashMap<>();//ordenado segun ingreso
        TreeMap<String,String> diccionario = new TreeMap<>();//ordenado por clave
        
        
        //agrego al diccionario valores
        diccionario.put("rojo", "red");
        diccionario.put("verde", "green");
        diccionario.put("azul", "blue");
        diccionario.put("amarillo", "yellow");
        diccionario.put("naranja", "orange");
        diccionario.put("blanco", "white");
        diccionario.put("negro", "black");
        
        System.out.println("Contenido del diccionario: ");
        System.out.println(diccionario);
        
        System.out.println("---------------------------");        
        
        System.out.print("Traduccion de rojo: ");
        System.out.println(diccionario.get("rojo"));
        
        System.out.println("---------------------------");        
        
        System.out.print("Traduccion de gris: ");
        System.out.println(diccionario.getOrDefault("gris","No se encontro el color gris"));
        
        System.out.println("---------------------------");        
        
        
        System.out.println("Claves del diccionario: ");
        System.out.println(diccionario.keySet());
        
        System.out.println("---------------------------");        
        
        System.out.println("Valores del  diccionario: ");
        System.out.println(diccionario.values());
        
        
        
        
    }
}
