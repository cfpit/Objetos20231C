

package checked;


public class NoHayMasPasajesException extends Exception{
    private String vuelo;//equivale a nombre de la clase Vuelo
    private int pedidos;//equivale a variable asientos de la clase Vuelo

    public NoHayMasPasajesException() {
    }

    public NoHayMasPasajesException(String vuelo, int pedidos) {
        this.vuelo = vuelo;
        this.pedidos = pedidos;
    }

    public String getVuelo() {
        return vuelo;
    }

    public void setVuelo(String vuelo) {
        this.vuelo = vuelo;
    }

    public int getPedidos() {
        return pedidos;
    }

    public void setPedidos(int pedidos) {
        this.pedidos = pedidos;
    }
    
    //metodos
    public void mostrarMensaje() {
        System.out.println("El vuelo " + this.vuelo + " no dispone de " +
                this.pedidos + " asientos para vender");
    }

    @Override
    public String toString() {
        return "NoHayMasPasajesException{" + "vuelo=" + vuelo + ", pedidos=" + pedidos + '}';
    }
}
