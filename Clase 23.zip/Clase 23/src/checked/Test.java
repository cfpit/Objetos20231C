package checked;

public class Test {
    public static void main(String[] args) throws NoHayMasPasajesException {
        
        try {
            //creo un vuelo
            Vuelo v = new Vuelo("ABC123", 100);

            //vendo pasajes
            v.vender(70);
            v.vender(15);
            v.vender(10);
            v.vender(20);//esta linea lanza excepcion

            //estado del vuelo
            System.out.println(v);
        } catch (NoHayMasPasajesException e) {
            e.mostrarMensaje();
        }
        
        
        
    }
}
