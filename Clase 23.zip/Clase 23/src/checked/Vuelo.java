package checked;

public class Vuelo {
    private String nombre;
    private int capacidad;

    public Vuelo() {}

    public Vuelo(String nombre, int capacidad) {
        this.setNombre(nombre);
        this.setCapacidad(capacidad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
    
    //metodos
    //atender la excepcion significa agregar la clausula throws en la 
    //firma del metodo susceptible de lanzar una o varias excepciones
    public void vender(int asientos) throws NoHayMasPasajesException {
        //si la capacidad es menor q los asientos q me piden 
        //entonces manualmente lanzo la excepcion (es decir, 
        // creo un objeto de la clase NoHayMasPasajesException)
        //q me muestre el mensaje de error
        if (capacidad < asientos) {
            throw new NoHayMasPasajesException(this.nombre, asientos);
        } else {
            this.setCapacidad(this.getCapacidad()- asientos);
        }
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", capacidad=" + capacidad + '}';
    }
}
