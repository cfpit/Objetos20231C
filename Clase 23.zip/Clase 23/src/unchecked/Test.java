package unchecked;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
//        int n1 = 5;
//        int n2 = 0;

        Scanner lector = new Scanner(System.in);
        
        System.out.println("n1 = ");
        int n1 = lector.nextInt();
        
        System.out.println("n2 = ");
        int n2 = lector.nextInt();
        
        System.out.println("n1 / n2 = " + (double)n1 / n2);
        System.out.println("sigue...");
        
    }
}
