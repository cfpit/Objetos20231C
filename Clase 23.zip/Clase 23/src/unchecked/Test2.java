package unchecked;

public class Test2 {
    public static void main(String[] args) {
        try 
        {
            //puntero a nulo
            String palabra = null;

            //esta linea lanza una NullPointerException
            System.out.println("Longitud de la palabra: " + palabra.length());
            
            System.out.println("Continua el bloque try...");
        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
        }
        
        System.out.println("Sigue ejecutandose la app...");
        
        
        
    }
}
