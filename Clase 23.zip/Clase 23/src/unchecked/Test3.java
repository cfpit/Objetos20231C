package unchecked;

public class Test3 {
    public static void main(String[] args) {
        try {
            String palabra = null;
            
//            System.out.println("Longitud  de la cadena: " + palabra.length());
            
            int n1 = Integer.parseInt("50");
            System.out.println("n1 = " + n1);
            
            int n2 = Integer.parseInt("Hola");
            System.out.println("n2 = " + n2);
        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
        } catch (NumberFormatException e) {
            System.out.println("Error de parseo");
        } catch (Exception e) {
            System.out.println("Se produjo un error");
        } finally {
            System.out.println("Sigue la ejecucion de la app...");
        }
    }
}
