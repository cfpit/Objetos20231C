package copiadorBinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            //creo los File para guardar la ruta de los archivos binarios
            File archivoOrigen = new File("src/copiadorBinario/foto.jpg");
            File archivoDestino = new File("src/copiadorBinario/copia.jpg");

            //creo los streams de lectura y escritura para binarios
            FileInputStream streamLectura = new FileInputStream(archivoOrigen);
            FileOutputStream streamEscritura = new FileOutputStream(archivoDestino);

            //bucle de copia (byte a byte)
            int unCaracter;
            
            while ((unCaracter = streamLectura.read()) != -1) {
                streamEscritura.write(unCaracter);
            }

            //cierro los streams
            streamLectura.close();
            streamEscritura.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo a copiar");
        } catch (IOException e) {
            System.out.println("Error de copia");
        }
    }
}
