-- selecciono la base x defecto
use pubs;

-- veo las tablas de la base seleccionada
show tables;

-- veo la estructura de la tabla autores
describe authors;

-- queries
-- listar todos los autores
select * from authors;-- * todos los campos

-- listar titulo, precio y fecha de publicacion
-- de los libros de cocina
select 	title as titulo,
		price precio,
        pubdate 'fecha de publicacion'
from 	titles
where	type like '%cook%';

-- listar los empleados cuyo nombre empiece con m
select	*
from	employee
where	fname like 'm%';

-- listar los libros que salen entre 10 y 20 U$s
select	*
from	titles
where	price between 10 and 20;

-- listar nombre y apellido de los empleados que 
-- trabajen como editores o diseñadores
select		concat(e.fname,' ',e.lname) empleado,
			j.job_desc 'puesto de trabajo'
from		employee e
inner join	jobs j on e.job_id = j.job_id
where		j.job_desc in ('designer','editor');


-- producto cartesiano
select		*
from		sales
cross join	stores
where		state = 'ca';

-- listar los titulos de negocio ordenados por precio
-- del mas caro al mas barato. En caso de igualdad
-- de precios, desempatar por nombre del libro en forma alfabetica
select		*
from		titles
where		type = 'business'
order by	price desc, title asc;

-- funciones de agrupacion
select	max(price) 'libro mas caro',
		min(price) 'libro mas barato',
        avg(price) promedio,
        count(title_id) cantidad,
        sum(price) total
from	titles;

-- agrupaciones
-- listar la cantidad y el libro mas caro segun cada categoria
select		type categoria,
			count(title_id) cantidad,
            max(price) 'libro mas caro'
from		titles
group by	type;

select		provincia,
			ciudad,
			count(dni) poblacion
from		censo
group by	provincia, ciudad;

-- listar las ventas por libreria y por titulo
-- dentro de cada libreria
select		stor_name libreria,
			title libro,
            sum(qty) ventas
from		titles t 
inner join	sales s on t.title_id = s.title_id
inner join	stores st on st.stor_id = s.stor_id
group by	stor_name, title;

-- crud = abmc

/*
	SQL
		--> DDL: lenguaje de definicion de datos
			--> create
            --> alter
            --> drop
            --> operan sobbre objetos de la base
				--> bd, tablas, vistas, indices, funciones, proc. almacenados
            
		--> DML: lenguaje de manipulacion de datos
			--> select
            --> insert
            --> update
            --> delete
            --> operan sobre registros de las tablas
*/

-- ORM : mapeo de objeto relacion
-- tabla = clase
-- campo de una tabla = atributo de una clase
-- un registro de una tabla = un objeto de una clase

create database colegio;

use colegio;

create table alumnos(nombre varchar(20), edad int);

insert into alumnos values ('Juan',25), ('Maria',30), ('Luis',20), ('Ana',40);

select * from alumnos;

update alumnos set edad = edad + 1 where nombre = 'Juan';
select * from alumnos;

delete from alumnos where nombre = 'Luis';
select * from alumnos;





