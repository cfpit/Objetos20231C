-- selecciono la base x defecto
use pubs;

-- veo las tablas de la base seleccionada
show tables;

-- veo la estructura de la tabla titles
describe titles;

-- queries
select * from employee;-- * todos los campos

-- listar nombre, apellido y fecha de ingreso de todos
-- los empleados q ingresaron en el año 1990
-- Ordenados en forma alfabetica
select 		concat(fname,' ',lname) as empleado,
			hire_date as 'fecha de ingreso'
from 		employee
where		year(hire_date) = 1990
order by	1;

-- funciones agrupadas
select	max(price) as 'precio mas caro',
		min(price) as 'precio mas barato',
		round((price), 2) as promedio,
		count(title_id) cantidad,
        sum(price) total
from	titles;





