package abmc;

import java.sql.SQLException;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Scanner lector = new Scanner(System.in);
        
        Conexion.obtenerConexion();
        
//        System.out.println("Consultar todos los alumnos");
//        Alumno.consultarTodos();
        
        System.out.println("---------------------------");
        
//        System.out.println("Consultar un alumno");
//
//        System.out.print("Ingresa el nombre del alumno:");
//        Alumno.consultarUno(lector.next());
        
//        System.out.println("Insercion");
//
//        System.out.println("nombre:");
//        System.out.println("edad:");
//        Alumno a = new Alumno(lector.next(),lector.nextInt());
//        Alumno.insertar(a);
//        Alumno.consultarTodos();
        
        System.out.println("Actualizacion");

        System.out.println("nombre anterior:");
        String nombreAnterior = lector.next();
        System.out.println("nombre nuevo:");
        String nombreNuevo = lector.next();
        
        Alumno.actualizar(nombreAnterior, nombreNuevo);
        Alumno.consultarTodos();
    }
}






