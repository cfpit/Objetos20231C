/*
    En esta parte, se define la clase ProgressBarDemo, que extiende de JFrame 
    para representar la ventana de la aplicación. El constructor ProgressBarDemo() 
    se encarga de configurar la apariencia y el diseño del JFrame. Se establece 
    el título de la ventana, la operación de cierre y se elige un diseño de flujo 
    para los componentes.

    Se crea un JProgressBar y se configura su tamaño preferido. Luego, se agrega 
    al JFrame. También se crea un JLabel con el texto inicial y se agrega al JFrame. 
    Finalmente, se establece el tamaño del JFrame y se lo centra en la pantalla.

    El método startProgress() es donde se inicia el progreso de la aplicación. 
    Comienza configurando un Timer que ejecutará una acción después de 3 segundos. 
    En este caso, la acción cambia el texto del JLabel a "Mensaje después de 3 
    segundos". Se establece setRepeats(false) para evitar que el Timer se repita 
    y finalmente se inicia el Timer con timer.start().

    A continuación, se configura un SwingWorker para manejar el progreso del 
    JProgressBar. 
    
    El método doInBackground() se ejecuta en un hilo separado y simula el trabajo 
    en segundo plano. En este caso, itera de 0 a 100 con un retraso de 100 
    milisegundos en cada iteración. Dentro del bucle, se llama al método publish() 
    para enviar el progreso actual al método process().

    El método process() se ejecuta en el hilo de despacho de eventos y actualiza 
    el valor del JProgressBar con el progreso actual.

    Finalmente, el método done() se ejecuta cuando el trabajo en segundo plano 
    ha finalizado. Aquí se actualiza el texto del JLabel a "Proceso completado".

    En el método main(), se crea una instancia de ProgressBarDemo, se hace 
    visible el JFrame llamando a frame.setVisible(true), y luego se llama al 
    método startProgress() para iniciar el progreso.
*/

package ejemplo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProgressBarDemo extends JFrame {
    private JProgressBar progressBar;
    private JLabel progressLabel;

    public ProgressBarDemo() {
        // Configuración del JFrame
        setTitle("ProgressBar Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Creación y configuración del JProgressBar
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(200, 30));
        add(progressBar);

        // Creación y configuración del JLabel
        progressLabel = new JLabel("Mensaje inicial");
        add(progressLabel);

        // Establecer el tamaño del JFrame
        setSize(300, 200);

        // Centrar el JFrame en la pantalla
        setLocationRelativeTo(null);
    }

    public void startProgress() {
        // Configuración del Timer para cambiar el mensaje después de 3 segundos
        Timer timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                progressLabel.setText("Mensaje después de 3 segundos");
            }
        });
        timer.setRepeats(false); // Evitar que el Timer se repita
        timer.start(); // Iniciar el Timer

        // Configuración del SwingWorker para el progreso del JProgressBar
        SwingWorker<Void, Integer> worker = new SwingWorker<Void, Integer>() {
            @Override
            protected Void doInBackground() throws Exception {
                // Simulación de trabajo en segundo plano
                for (int i = 0; i <= 100; i++) {
                    Thread.sleep(100); // Retraso para simular el progreso
                    publish(i); // Enviar el progreso actual al método process()
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                int progress = chunks.get(chunks.size() - 1);
                progressBar.setValue(progress); // Actualizar el valor del JProgressBar
            }

            @Override
            protected void done() {
                progressLabel.setText("Proceso completado"); // Actualizar el JLabel al finalizar el progreso
            }
        };

        worker.execute(); // Iniciar el SwingWorker
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProgressBarDemo frame = new ProgressBarDemo(); // Crear una instancia de ProgressBarDemo
            frame.setVisible(true); // Hacer visible el JFrame
            frame.startProgress(); // Iniciar el progreso
        });
    }
}