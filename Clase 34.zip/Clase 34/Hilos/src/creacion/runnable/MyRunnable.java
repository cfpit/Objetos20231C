/*
Creamos una clase MyRunnable que implementa la interfaz Runnable. Cada instancia 
de MyRunnable representa una tarea que puede ser ejecutada por un hilo. En el 
método run(), imprimimos un mensaje cinco veces con el nombre del hilo y un contador. 
Luego, se realiza una pausa de un segundo utilizando Thread.sleep(1000).

En el método main, creamos tres instancias de MyRunnable con diferentes nombres 
y las pasamos como argumento al constructor de Thread. Luego, iniciamos cada hilo 
utilizando el método start(). Esto permite que cada hilo se ejecute en paralelo, 
imprimiendo sus mensajes de saludo en la consola.


En Java, hay una diferencia importante entre los métodos start() y run() al 
trabajar con hilos.

start(): Este método es parte de la clase Thread y se utiliza para iniciar la 
ejecución del hilo. Cuando se llama al método start(), se realiza la preparación 
necesaria para el hilo, se reserva memoria y se invoca el método run() en un 
nuevo hilo de ejecución. El código dentro del método run() se ejecuta en paralelo 
con otros hilos en el programa.

run(): Este método contiene el código que se ejecuta en el hilo. Debe ser 
proporcionado por la clase que implementa la lógica del hilo. Sin embargo, si 
llamamos directamente al método run() en lugar de usar start(), el código se 
ejecuta secuencialmente en el mismo hilo desde el que se realizó la llamada. No 
se crea un nuevo hilo y no se aprovechan las ventajas de la concurrencia.

Es importante utilizar start() en lugar de run() para iniciar un hilo correctamente 
y permitir que se ejecute de manera concurrente con otros hilos. El método start() 
se encarga de realizar las tareas de inicialización y crear un nuevo hilo de 
ejecución. Por otro lado, el método run() define la lógica que se ejecutará en 
el hilo, pero solo debe ser llamado indirectamente a través de start().


*/

package creacion.runnable;

class MyRunnable implements Runnable {
    private String name;
    
    public MyRunnable(String name) {
        this.name = name;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Hola desde " + name + " (" + i + ")");
            try {
                Thread.sleep(1000); // Pausa de 1 segundo entre cada mensaje
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
