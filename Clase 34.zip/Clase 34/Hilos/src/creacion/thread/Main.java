package creacion.thread;

public class Main {
    public static void main(String[] args) {
        Thread thread1 = new MyThread("Hilo 1");
        Thread thread2 = new MyThread("Hilo 2");
        Thread thread3 = new MyThread("Hilo 3");
        
        thread1.start();
        thread2.start();
        thread3.start();
    }
}



    
    
    

