/*
Creamos una clase MyThread que extiende la clase Thread. Cada instancia de MyThread 
representa un hilo independiente. En el método run(), imprimimos un mensaje cinco 
veces con el nombre del hilo y un contador. Luego, se realiza una pausa de un segundo 
utilizando Thread.sleep(1000).

En el método main, creamos tres instancias de MyThread con diferentes nombres y 
las iniciamos utilizando el método start(). Esto permite que cada hilo se ejecute 
en paralelo, imprimiendo sus mensajes de saludo en la consola.
*/

package creacion.thread;

class MyThread extends Thread {
    private String name;
    
    public MyThread(String name) {
        this.name = name;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Hola desde " + name + " (" + i + ")");
            try {
//                El método sleep() simplemente le dice al thread que duerma 
//                durante los milisegundos especificados. Se debería utilizar 
//                sleep() cuando se pretenda retrasar la ejecución del thread, 
//                sleep() no consume recursos del sistema mientras el thread duerme. 
//                De esta forma otros threads pueden seguir funcionando.
                Thread.sleep(1000); // Pausa de 1 segundo entre cada mensaje
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
