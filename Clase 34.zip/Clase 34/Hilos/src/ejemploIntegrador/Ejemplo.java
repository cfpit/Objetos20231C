/*
La palabra clave synchronized 
Se utiliza para lograr la sincronización de hilos y evitar problemas de 
concurrencia en el acceso a recursos compartidos. Se  puede aplicar a bloques de 
código o a métodos.

Cuando se marca un bloque de código con synchronized, se asegura que solo un hilo 
pueda ejecutar ese bloque a la vez. Esto es útil cuando múltiples hilos intentan 
acceder y modificar datos compartidos al mismo tiempo, lo que podría llevar a 
resultados inconsistentes o a condiciones de carrera.

Cuando se marca un método con synchronized, se asegura que solo un hilo pueda 
ejecutar ese método a la vez. Esto proporciona un nivel de sincronización en el 
nivel del método completo, lo que puede simplificar la implementación y mejorar 
la legibilidad del código.

El uso de synchronized garantiza la exclusión mutua, lo que significa que solo 
un hilo puede ejecutar el bloque o método sincronizado en un momento dado. Además, 
establece una barrera de memoria, lo que garantiza que los cambios realizados por 
un hilo sean visibles para otros hilos.

Es importante tener en cuenta que el uso indiscriminado de synchronized puede 
afectar el rendimiento de la aplicación, ya que bloquea el acceso simultáneo de 
los hilos. Por lo tanto, se debe aplicar con cuidado y solo cuando sea necesario 
garantizar la consistencia de los datos compartidos. En algunos casos, se pueden 
utilizar otras estructuras de sincronización más especializadas, como Lock o 
Semaphore, dependiendo de los requisitos específicos.


Planificación de Threads
Un tema fundamental dentro de la programación multihilo es la planificación de 
los hilos. Este concepto se refiere a la política a seguir de qué hilo toma el 
control del procesador y de cuando.

Obviamente en el caso de que un hilo está bloqueado esperando una operación de IO 
este hilo debería dejar el control del procesador y que este control lo tomara 
otro hilo que si pudiera hacer uso del tiempo de CPU.¿Pero qué pasa si hay más de 
un hilo esperando?.¿A cuál de ellos le otorgamos el control del procesador?.

Prioridades
Para determinar qué hilo debe ejecutarse primero, cada hilo posee su propia 
prioridad: un hilo de prioridad más alta que se encuentre en el estado listo 
entrará antes en el estado de ejecución que otro de menor prioridad.

Para establecer la prioridad de un thread se utiliza el método setPriority() de 
la siguiente manera:
h1.setPriority(10); //Le concede la mayor prioridad
h2.setPriority(1); //Le concede la menor prioridad

También existen constantes definidas para la asignación de prioridad estas son :
MIN_PRIORITY=1;
NORM_PRIORITY=5;
MAX_PRIORITY=10;

Las cuales se pueden utilizar de la siguiente manera:
h1.setPriority(Thread.MAX_PRIORITY); //Le concede la mayor prioridad
h2.setPriority(Thread.MIN_PRIORITY); //Le concede la menor prioridad

Los métodos notify() y notifyAll()
Deben ser llamados desde el thread que tiene bloqueado el objeto para activar el 
resto de threads que están esperando la liberación de un objeto. Un thread se
convierte en propietario del bloqueo de un objeto ejecutando un método sincronizado 
del objeto.

Cuando un thread llama a wait() en un método de un objeto dado, queda detenido 
hasta que otro thread llame a notify() en algún método del mismo objeto.

Se utilizó notifyAll() en lugar de notify(), porque en el segundo caso sólo se 
notificaría al primer thread (el primer empleado en llegar) y no a los demás, que 
se quedarían en el wait().

Esta es la diferencia principal entre notifyAll() y notify(), el notifyAll() saca 
a todos los objetos thread del estado en espera, mientras que el método notify() 
saca a un solo objeto thread (imposible determinar cual al menos que tengan 
prioridades seteadas) del estado en espera.

Como se ve en la salida, a pesar de que los empleados están en condiciones de 
saludar, no lo hacen hasta que no llega el jefe:
*/

package ejemploIntegrador;

public class Ejemplo {

    public static void main(String argv[]) {
        Saludo hola = new Saludo();
        
        Personal pablo = new Personal(hola, "Pablo", false);
        Personal luis = new Personal(hola, "Luis", false);
        Personal andrea = new Personal(hola, "Andrea", false);
        Personal pedro = new Personal(hola, "Pedro", false);
        Personal jefe = new Personal(hola, "JEFE", true);
        
        pablo.start();
        luis.start();
        
        andrea.start();
        pedro.start();
        
        jefe.start();
        
        try {
            pablo.join();
            luis.join();
            andrea.join();
            pedro.join();
            jefe.join();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
