package ejemploIntegrador;

class Personal extends Thread {

    String nombre;
    Saludo saludo;
    boolean esJefe;

    Personal(Saludo s, String n, boolean j) {
        nombre = n;
        saludo = s;
        esJefe = j;
    }

    public void run() {
        System.out.println("(" + nombre + " llega)");
        if (esJefe) {
            saludo.saludoJefe();
        } else {
            saludo.esperarJefe(nombre);
        }
    }
}
