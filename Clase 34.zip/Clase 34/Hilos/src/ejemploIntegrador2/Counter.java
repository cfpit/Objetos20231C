

package ejemploIntegrador2;


public class Counter {
    private int count;
    
    public synchronized void increment() {
        count++;
        notify();
    }
    
    public synchronized void decrement() {
        while (count == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        count--;
        notify();
    }
    
    public int getCount() {
        return count;
    }
}
