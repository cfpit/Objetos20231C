

package ejemploIntegrador2;


public class DecrementRunnable implements Runnable{
    private Counter counter;
    
    public DecrementRunnable(Counter counter) {
        this.counter = counter;
    }
    
    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            counter.decrement();
            Thread.yield();
        }
    }
}
