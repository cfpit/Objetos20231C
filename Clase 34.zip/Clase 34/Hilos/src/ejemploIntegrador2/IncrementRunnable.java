

package ejemploIntegrador2;


public class IncrementRunnable implements Runnable{
    private Counter counter;
    
    public IncrementRunnable(Counter counter) {
        this.counter = counter;
    }
    
    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            counter.increment();
            Thread.yield();
        }
    }
}
