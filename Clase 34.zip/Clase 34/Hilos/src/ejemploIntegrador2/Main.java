/*
En este ejemplo, Los hilos incrementan y decrementan un contador compartido de 
manera sincronizada, evitando problemas de concurrencia y garantizando un resultado 
consistente.

Tenemos una clase Counter que mantiene un contador count. La clase Counter tiene 
dos métodos sincronizados: increment() y decrement(). Cuando un método se declara 
como synchronized, implica que solo un hilo puede acceder a ese método a la vez. 
Esto asegura que no se produzcan problemas de concurrencia al manipular datos 
compartidos. Luego, increment() incrementa el contador en 1 y llama a notify(), 
Esto notifica a cualquier otro hilo en espera que pueda continuar su ejecución. 
Mientras que decrement() decrementa el contador en 1 después de esperar si el 
contador es 0. El método getCount() proporciona el valor actual del contador.

La clase IncrementRunnable y DecrementRunnable implementan la interfaz Runnable 
y reciben una instancia de Counter en su constructor. Estas clases son responsables 
de incrementar y decrementar el contador, respectivamente. Dentro de sus métodos 
run(), hay un bucle que realiza la operación correspondiente en el contador 
llamando a los métodos increment() y decrement() de la instancia de Counter. 
También se utiliza Thread.yield() para ceder el turno al otro hilo después de 
cada operación.

En el método main(), se crean dos hilos utilizando las instancias de 
IncrementRunnable y DecrementRunnable. Luego, se llama al método start() de cada 
hilo para iniciar su ejecución en paralelo. A continuación, se utiliza join() 
para esperar a que ambos hilos finalicen antes de imprimir el resultado final 
del contador.

El método join() se utiliza para hacer que un hilo espere hasta que otro hilo haya 
completado su ejecución. Cuando se llama al método join() en un hilo, el hilo 
actual se bloquea y espera a que el hilo en el que se llamó termine antes de 
continuar su ejecución.

En el contexto del ejemplo, se utiliza el método join() para asegurarse de que el 
hilo principal (el hilo que ejecuta el método main()) espere a que los hilos 
incrementThread y decrementThread finalicen antes de imprimir el mensaje final.

Cuando se llama a join() en un hilo, el hilo actual se bloquea hasta que el hilo 
en el que se llamó complete su ejecución. En este caso, el hilo principal llama 
a join() en incrementThread y decrementThread, lo que significa que el hilo principal 
esperará hasta que ambos hilos hayan terminado.

Una vez que los hilos incrementThread y decrementThread hayan finalizado, el hilo 
principal continuará su ejecución y se imprimirá el mensaje final "El conteo ha 
finalizado. Resultado: " seguido del valor actual del contador.
*/

package ejemploIntegrador2;


public class Main {
    public static void main(String[] args) {
        Counter counter = new Counter();
        
        Thread incrementThread = new Thread(new IncrementRunnable(counter));
        Thread decrementThread = new Thread(new DecrementRunnable(counter));
        
        incrementThread.start();
        decrementThread.start();
        
        try {
            incrementThread.join();
            decrementThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("El conteo ha finalizado. Resultado: " + counter.getCount());
    }
}
