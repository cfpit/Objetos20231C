/*
La interfaz Callable en Java es similar a la interfaz Runnable, pero con una 
diferencia importante: la interfaz Callable puede devolver un resultado y lanzar 
una excepción.

La interfaz Callable se utiliza generalmente en combinación con la clase 
ExecutorService para ejecutar tareas en hilos separados y obtener resultados de 
esas tareas.

En este ejemplo, se crea un ExecutorService utilizando 
Executors.newSingleThreadExecutor(), lo que crea un ejecutor con un solo hilo. 
Luego, se crea una instancia de la clase MyCallable, que implementa la interfaz 
Callable<Integer>. La implementación del método call() realiza alguna tarea, en 
este caso, calcula la suma de los números del 1 al 10 y devuelve el resultado.

La tarea MyCallable se envía al ExecutorService utilizando el método submit(), 
que devuelve un objeto Future que representa el resultado de la tarea. Luego, se 
utiliza el método get() del objeto Future para obtener el resultado de la tarea. 
Si la tarea aún no ha terminado, el hilo actual se bloqueará hasta que la tarea 
se complete y se obtenga el resultado.

En este caso, el resultado se imprime en la consola. También se maneja cualquier 
excepción que pueda ocurrir durante la ejecución de la tarea.

Finalmente, se apaga el ExecutorService llamando al método shutdown().

La interfaz Callable es útil cuando necesitas obtener resultados de tareas 
ejecutadas en hilos separados y también manejar excepciones específicas que pueden 
ocurrir durante la ejecución de esas tareas.
*/

package interfaceCallable;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        
        // Crear una instancia de la clase MyCallable
        Callable<Integer> myCallable = new MyCallable();
        
        // Ejecutar la tarea y obtener un Future que representa el resultado
        Future<Integer> future = executorService.submit(myCallable);
        
        try {
            // Obtener el resultado de la tarea
            int result = future.get();
            
            System.out.println("Resultado: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        executorService.shutdown();
    }
}
