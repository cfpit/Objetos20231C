package interfaceCallable;

import java.util.concurrent.Callable;

class MyCallable implements Callable<Integer> {
    @Override
    public Integer call() throws Exception {
        // Realizar alguna tarea que devuelve un resultado
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        
        return sum;
    }
}
