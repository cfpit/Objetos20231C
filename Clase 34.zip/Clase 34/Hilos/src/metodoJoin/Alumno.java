/*
El método join()

Si un thread necesita esperar a que otro termine (por ejemplo el thread padre 
esperar a que termine el hijo) puede usar el método join(). ¿Por qué se llama 
así? Crear un proceso es como una bifurcación, se abren dos caminos, que uno 
espere a otro es lo contrario, una unificación.

A continuación se presenta un ejemplo más complejo: una reunión de alumnos. El 
siguiente ejemplo usa threads para activar simultáneamente tres objetos de la 
misma clase, que comparten los recursos del procesador peleándose para escribir 
a la pantalla.

El método join() qué llamamos al final hace que el programa principal espere 
hasta que este thread esté "muerto" (finalizada su ejecución). Este método puede 
disparar la excepción InterruptedException, por lo que lo hemos tenido en cuenta 
en el encabezamiento del método.

En nuestro ejemplo, simplemente a cada instancia de Amigo(...) que creamos la 
hemos ligado a un thread y puesto a andar. Corren todas en paralelo hasta que 
mueren de muerte natural, y también el programa principal acaba.

El método yield()

Si se está utilizando un sistema operativo no preemptivo, deben explícitamente 
indicarle al procesador cuando puede ejecutar (dar paso) a otra tarea.
*/

package metodoJoin;

class Alumno implements Runnable {

    String mensaje;

    public Alumno(String nombre) {
        mensaje = "Hola, soy " + nombre + " y este es mi mensaje ";
    }

//    Esta anotación indica que el método que sigue a continuación es una 
//    implementación del método definido en la interfaz Runnable.
    @Override
    
//    Se implementa el método run() de la interfaz Runnable. Este método contiene 
//    la lógica que se ejecutará en el hilo cuando se inicie.
    public void run() {
        for (int i = 1; i < 6; i++) {
            String msg = mensaje + i;
            System.out.println(msg);
            
//            Esta llamada sugiere que se ceda el turno a otros hilos. Es una 
//            manera de indicar que el hilo actual está dispuesto a ceder su 
//            tiempo de ejecución para permitir que otros hilos se ejecuten.
            Thread.yield();

        }
    }
}
