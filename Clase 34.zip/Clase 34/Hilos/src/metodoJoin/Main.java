package metodoJoin;

public class Main {

    public static void main(String args[]) throws InterruptedException {
        Thread juan = new Thread(new Alumno("Juan"));
        Thread pepe = new Thread(new Alumno("Pepe"));
        Thread andres = new Thread(new Alumno("Andres"));
        
        juan.start();
        juan.join();
        
        pepe.start();
        pepe.join();
        
        andres.start();
        andres.join();
    }
}
