

package productorConsumidor;

import java.util.LinkedList;


public class Buffer {
    private LinkedList<Integer> queue;
    private final int CAPACITY = 5;
    
    public Buffer() {
        queue = new LinkedList<>();
    }
    
    public synchronized void produce(int item) {
        while (queue.size() == CAPACITY) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        queue.add(item);
        System.out.println("Producido: " + item);
        
        notify();
    }
    
    public synchronized void consume() {
        while (queue.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        int item = queue.removeFirst();
        System.out.println("Consumido: " + item);
        
        notify();
    }
}
