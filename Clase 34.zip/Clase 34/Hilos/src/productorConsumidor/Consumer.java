

package productorConsumidor;


public class Consumer implements Runnable{
    private Buffer buffer;
    
    public Consumer(Buffer buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            buffer.consume();
        }
    }
}
