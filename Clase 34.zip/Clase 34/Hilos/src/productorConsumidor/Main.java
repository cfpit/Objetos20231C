/*
En este ejemplo, hay una clase Buffer que actúa como un búfer compartido entre 
el productor y el consumidor. El búfer utiliza una lista enlazada para almacenar 
los elementos producidos. El tamaño máximo del búfer se establece en 5.

El método produce() se utiliza para que el productor agregue elementos al búfer. 
Si el búfer está lleno, el productor se bloquea llamando a wait(), lo que significa 
que esperará hasta que haya espacio disponible en el búfer. Cuando el búfer tiene 
espacio, el productor agrega el elemento y luego llama a notify() para notificar 
al consumidor que hay elementos disponibles para consumir.

El método consume() se utiliza para que el consumidor retire elementos del búfer. 
Si el búfer está vacío, el consumidor se bloquea llamando a wait(), lo que significa 
que esperará hasta que haya elementos en el búfer para consumir. Cuando hay elementos 
disponibles, el consumidor retira el elemento y luego llama a notify() para 
notificar al productor que hay espacio disponible en el búfer.

En el método main(), se crean instancias de Producer y Consumer que comparten la 
misma instancia de Buffer. Luego, se crean y se inician los hilos producerThread 
y consumerThread.

Cuando se ejecuta el programa, el productor produce los números del 1 al 10 y los 
agrega al búfer. El consumidor consume los elementos del búfer uno por uno. Ambos 
hilos se sincronizan utilizando wait() y notify(), lo que garantiza que el 
productor espere cuando el búfer esté lleno y el consumidor espere cuando el búfer 
esté vacío, evitando que se produzcan condiciones de carrera y asegurando que ambos 
hilos se coordinen correctamente en la producción y consumo de elementos.
*/

package productorConsumidor;

public class Main {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        
        Thread producerThread = new Thread(new Producer(buffer));
        Thread consumerThread = new Thread(new Consumer(buffer));
        
        producerThread.start();
        consumerThread.start();
    }
}
