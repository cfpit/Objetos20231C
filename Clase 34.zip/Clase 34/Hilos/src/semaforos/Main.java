/*
En este ejemplo, se crea un semáforo semaphore con un permiso disponible. Luego 
se crean dos hilos thread1 y thread2 que comparten el mismo semáforo. Cada hilo 
es una instancia de la clase Worker, que implementa la interfaz Runnable.

Dentro del método run() de la clase Worker, se muestra un mensaje indicando que 
el hilo está esperando el semáforo. Luego, se llama al método acquire() del semáforo 
para adquirir un permiso. Si no hay permisos disponibles, el hilo se bloqueará 
hasta que se libere un permiso.

Una vez que un hilo ha adquirido un permiso, muestra un mensaje indicando que ha 
obtenido el semáforo y realiza el trabajo protegido por el semáforo. En este caso, 
no hay ningún trabajo específico, pero esto podría ser cualquier sección crítica 
o recurso compartido que se deba proteger de acceso simultáneo.

Después de realizar el trabajo protegido, el hilo muestra un mensaje indicando que 
está liberando el semáforo y llama al método release() del semáforo para liberar 
el permiso adquirido.

Cuando se ejecuta el programa, los hilos compiten por el semáforo. Solo uno de los 
hilos puede adquirir el semáforo a la vez, mientras que el otro hilo espera si el 
semáforo está ocupado. Esto garantiza que solo un hilo acceda al trabajo protegido 
a la vez, sincronizando efectivamente la ejecución de los hilos mediante el uso 
de semáforos.
*/

package semaforos;

import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {
        Semaphore semaphore = new Semaphore(1); // Crear semáforo con un permiso disponible
        
        Thread thread1 = new Thread(new Worker(semaphore, "Hilo 1"));
        Thread thread2 = new Thread(new Worker(semaphore, "Hilo 2"));
        
        thread1.start();
        thread2.start();
    }
}
