package semaforos;

import java.util.concurrent.Semaphore;


class Worker implements Runnable {
    private Semaphore semaphore;
    private String name;
    
    public Worker(Semaphore semaphore, String name) {
        this.semaphore = semaphore;
        this.name = name;
    }
    
    @Override
    public void run() {
        try {
            System.out.println(name + " está esperando el semáforo.");
            semaphore.acquire(); // Adquirir un permiso del semáforo
            
            System.out.println(name + " ha obtenido el semáforo.");
            
            // Realizar trabajo protegido por el semáforo
            
            System.out.println(name + " está liberando el semáforo.");
            semaphore.release(); // Liberar el permiso del semáforo
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
