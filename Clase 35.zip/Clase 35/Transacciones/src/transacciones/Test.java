/*
Se realiza una transacción que consiste en insertar un nuevo registro en la tabla 
"users" y luego actualizar la edad de ese usuario. Si ocurre algún error durante 
la transacción, se realiza un rollback para deshacer los cambios y se muestra un 
mensaje de error.
*/

package transacciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;


public class Test {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/mibase";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Desactivar el autocommit para habilitar las transacciones
            connection.setAutoCommit(false);

            // Realizar las operaciones de la transacción
            insertData(connection, "John", 25);
            updateData(connection, "John", 30);

            // Confirmar la transacción
            connection.commit();

            System.out.println("Transacción completada con éxito.");
        } catch (SQLException e) {
            System.err.println("Error en la transacción. Revertir cambios...");
            if (connection != null) {
                try {
                    connection.rollback();
                    System.out.println("Cambios revertidos con éxito.");
                } catch (SQLException ex) {
                    System.err.println("Error al revertir los cambios.");
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            // Cerrar la conexión
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void insertData(Connection connection, String name, int age) throws SQLException {
        String sql = "INSERT INTO users (name, age) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.executeUpdate();
        }
    }

    private static void updateData(Connection connection, String name, int newAge) throws SQLException {
        String sql = "UPDATE users SET age = ? WHERE name = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, newAge);
            statement.setString(2, name);
            statement.executeUpdate();
        }
    }
}
