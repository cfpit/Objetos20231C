-- Crear la base de datos
CREATE DATABASE mibase;

-- Usar la base de datos
USE mibase;

-- Crear la tabla "users"
CREATE TABLE users (
    id INT AUTO_INCREMENT,
    name VARCHAR(50),
    age INT,
    PRIMARY KEY (id)
);
