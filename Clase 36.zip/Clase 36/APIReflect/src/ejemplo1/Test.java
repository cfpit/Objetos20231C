/*
El API Reflection de Java es una parte de la plataforma Java que permite examinar 
y manipular la estructura, el comportamiento y la información de las clases en 
tiempo de ejecución. Proporciona capacidades para obtener información sobre las 
clases, campos, métodos, constructores, interfaces, anotaciones, etc. de un 
programa en ejecución.

Se intenta cargar la clase com.example.MyClass. Si la clase no se encuentra, se 
captura la excepción ClassNotFoundException y se imprime un mensaje de error. 
Luego se reemplaza "com.example.MyClass" por "ejemplo1.Persona" que si existe.
 */
package ejemplo1;

public class Test {

    public static void main(String[] args) {
        try {
//    Class<?> clase = Class.forName("com.example.MyClass");
            Class<?> clase = Class.forName("ejemplo1.Persona");
            
            System.out.println("Clase cargada: " + clase.getName());
            
        } catch (ClassNotFoundException e) {
            System.err.println("La clase no se pudo encontrar: " + e.getMessage());
        }

    }
}
