/*
En este ejemplo, se obtienen todos los campos declarados en la clase MyClass. El 
método getDeclaredFields() devuelve un array de objetos Field que representan los 
campos declarados en la clase. Luego, se itera sobre el array y se imprime el 
nombre de cada campo.
 */
package ejemplo2;

import ejemplo1.Persona;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Test {

    public static void main(String[] args) {
        Class<?> myClass = Persona.class;
        
        Field[] fields = myClass.getDeclaredFields();
        
        for (Field field : fields) {
            System.out.println(field.getName());
        }

    }

}
