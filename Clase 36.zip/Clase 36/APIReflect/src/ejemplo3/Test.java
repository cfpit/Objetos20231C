/*
Aquí se obtienen todos los métodos declarados en la clase MyClass. El método 
getDeclaredMethods() devuelve un array de objetos Method que representan los 
métodos declarados en la clase. Luego, se itera sobre el array y se imprime el 
nombre de cada método.
*/
package ejemplo3;

import ejemplo1.Persona;
import java.lang.reflect.Method;

public class Test {
    public static void main(String[] args) {
        Class<?> myClass = Persona.class;
        
Method[] methods = myClass.getDeclaredMethods();

for (Method method : methods) {
    System.out.println(method.getName());
}

    }
}
