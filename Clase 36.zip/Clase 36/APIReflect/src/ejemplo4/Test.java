/*
En este ejemplo, se obtienen todos los constructores declarados en la clase MyClass. 
El método getConstructors() devuelve un array de objetos Constructor que representan 
los constructores declarados en la clase. Luego, se itera sobre el array y se imprime 
el nombre de cada constructor.
*/
package ejemplo4;

import ejemplo1.Persona;
import java.lang.reflect.Constructor;

public class Test {

    public static void main(String[] args) {
        Class<?> miClase = Persona.class;
        
        Constructor<?>[] constructors = miClase.getConstructors();
        
        for (Constructor<?> constructor : constructors) {
            System.out.println(constructor.getName());
        }

    }
}
