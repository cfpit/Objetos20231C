/*
En este ejemplo, se accede y se lee el valor de un campo llamado "myField" en un 
objeto obj. Primero, se obtiene una referencia al campo utilizando getDeclaredField("myField"). 
Luego, se establece setAccessible(true) para acceder a campos privados. Finalmente, 
se utiliza field.get(obj) para obtener el valor del campo y se imprime.
*/
package ejemplo5;

import ejemplo1.Persona;
import java.lang.reflect.Field;

public class Test {

    public static void main(String[] args) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Class<?> miClase = Persona.class;
        Field field = miClase.getDeclaredField("edad");
        field.setAccessible(true); // Necesario si el campo es privado
        
        // Suponiendo que tienes una instancia válida de la clase
        Persona p = new Persona("Juan", 25); 


        Object valor = field.get(p);
        System.out.println(valor);
    }

}
