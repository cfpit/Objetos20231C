/*
Aquí se establece el valor de un campo llamado "nombre" en un objeto p. Primero, 
se obtiene una referencia al campo utilizando getDeclaredField("nombre"). Luego, 
se establece setAccessible(true) para acceder a campos privados. Finalmente, se 
utiliza field.set(p, nuevoNombre) para establecer un nuevo valor en el campo.
*/

package ejemplo6;

import ejemplo1.Persona;
import java.lang.reflect.Field;

public class Test {

    public static void main(String[] args) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Class<?> myClass = Persona.class;
        Field field = myClass.getDeclaredField("nombre");
        field.setAccessible(true); // Necesario si el campo es privado

        // Suponiendo que tienes una instancia válida de la clase
        Persona p = new Persona("Maria", 30);

        // Suponiendo que el campo es de tipo String
        String nuevoNombre = "Ana";

        field.set(p, nuevoNombre);
        
        System.out.println(p);

    }
}
