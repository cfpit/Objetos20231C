package clasesinternas;

public class Main {
    public static void main(String[] args) {
        // Crear una instancia de OuterClass
        OuterClass outer = new OuterClass();

        // Crear una instancia de InnerClass
        OuterClass.InnerClass inner = outer.new InnerClass();

        // Llamar al método de la clase interna
        inner.display();
    }
}








