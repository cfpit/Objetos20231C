/*
La clase interna de Java o clase anidada es una clase que se declara dentro de la 
clase o interfaz.

Usamos clases internas para agrupar lógicamente clases e interfaces en un solo 
lugar para que sean más legibles y fáciles de mantener.

Además, puede acceder a todos los miembros de la clase externa, incluidos los 
miembros y métodos de datos privados.

Ventajas:
a) Las clases anidadas representan un tipo particular de relación que puede acceder 
a todos los miembros (miembros de datos y métodos) de la clase externa, incluidos 
los privados.

b) Las clases anidadas se utilizan para desarrollar un código más legible y mantenible 
porque agrupa lógicamente las clases y las interfaces en un solo lugar.

c) Optimización de código : requiere menos código para escribir.

d) A veces, los usuarios necesitan programar una clase de tal manera que ninguna 
otra clase pueda acceder a ella. Por tanto, sería mejor que lo incluyeras dentro 
de otras clases.
*/
package clasesinternas;

public class OuterClass {

    private int outerVariable = 10;

    // Clase interna
    public class InnerClass {

        public void display() {
            System.out.println("Valor de outerVariable: " + outerVariable);
        }
    }
}
