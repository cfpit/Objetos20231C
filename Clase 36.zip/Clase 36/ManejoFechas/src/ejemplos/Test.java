package ejemplos;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class Test {

    public static void main(String[] args) {
        long currentTimeMillis = System.currentTimeMillis();
        System.out.println("Fecha y hora actual en milisegundos desde el 1 de enero de 1970: " + currentTimeMillis);
        
        System.out.println("--------------------------------------------------");

        Date date = new Date();
        System.out.println("Fecha y hora actual: " + date);
        
        System.out.println("--------------------------------------------------");

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        System.out.println("Fecha actual: " + day + "/" + (month + 1) + "/" + year);
        
        System.out.println("--------------------------------------------------");

        Date date2 = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        String formattedDate = sdf.format(date2);
        System.out.println("Fecha y hora formateadas: " + formattedDate);
        
        System.out.println("--------------------------------------------------");

        TimeZone timeZone = TimeZone.getDefault();
        System.out.println("Zona horaria predeterminada: " + timeZone.getID());

    }
}
