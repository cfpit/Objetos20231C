package ejemplo;

public class Test {
    public static void main(String[] args) {
        int segundos = 5; // Duración del temporizador en segundos

        System.out.println("Temporizador iniciado...");
        
        try {
            // Pausa la ejecución durante el tiempo especificado en milisegundos
            Thread.sleep(segundos * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Temporizador finalizado.");
    }
}
