/*
Este código crea un cliente TCP que se conecta a un servidor en la máquina "localhost" 
en el puerto 4321. El cliente luego lee los datos recibidos del servidor y los 
imprime en la consola.

Aquí hay una descripción de los pasos principales en el código:

a)Se crea un Socket y se establece una conexión con el servidor utilizando 
new Socket("localhost", 4321).

b)Se obtiene un InputStream asociado con el socket llamando a socket.getInputStream().

c)El cliente entra en un bucle y lee datos del servidor mediante inputStream.read(). 
El bucle se ejecuta hasta que se alcance el final del flujo 
(-1 indica el final del flujo).

d)Cada byte leído se interpreta como un carácter y se imprime en la consola 
utilizando System.out.print((char) c).

e)Se cierra la conexión del socket llamando a socket.close().

f)Este código implementa un cliente TCP básico que se conecta a un servidor y 
recibe datos del servidor. Recuerda que este es solo un ejemplo básico y no se 
incluyen consideraciones avanzadas como el manejo de errores, el envío de datos 
al servidor o la comunicación bidireccional.

*/

package TCP;

import java.net.*;
import java.io.*;

class Cliente {

    public static void main(String args[]) throws IOException, InterruptedException {
        int c;
        Socket s = null;
        InputStream sIn;

        // Abrimos una conexión con localhost en el puerto 4321
        try 
        {
            s = new Socket("localhost", 5001);
        } 
        catch (IOException e) 
        {
            System.out.println(e);
        }

        // Obtenemos un controlador de entrada del socket
        sIn = s.getInputStream();
        
        // Dormimos el hilo durante 3 segundos
        Thread.sleep(3000);
        
        while ((c = sIn.read()) != -1) 
        {
            System.out.print((char) c);
        }
        s.close();
    }
}
