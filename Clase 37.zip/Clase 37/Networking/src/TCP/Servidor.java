/*
Este código crea un servidor TCP que escucha en el puerto 4321 y espera conexiones 
de clientes. Cuando un cliente se conecta, el servidor envía la cadena de texto 
"Tutorial de Java!" al cliente y luego cierra la conexión.

Aquí hay una descripción de los pasos principales en el código:

a)Se crea un ServerSocket en el puerto 4321 utilizando new ServerSocket(4321, 300).

b)El servidor entra en un bucle infinito para escuchar y aceptar conexiones entrantes.

c)Cuando se establece una conexión con un cliente, se crea un Socket de cliente 
utilizando serverSocket.accept().

d)Se obtiene un OutputStream asociado con el socket del cliente llamando a 
clientSocket.getOutputStream().

e)Se envía la cadena de texto "Tutorial de Java!" al cliente escribiendo los 
caracteres uno por uno en el OutputStream.

f)La conexión con el cliente se cierra llamando a clientSocket.close().

g)El servidor vuelve al paso 3 y espera la siguiente conexión entrante.

h)Este código proporciona una base para implementar un servidor TCP simple en 
Java. Ten en cuenta que es solo un ejemplo básico y no se incluyen 
consideraciones de manejo de errores o manejo de múltiples clientes simultáneos. 
Para un servidor TCP más robusto, es posible que desees considerar el uso de hilos 
o subprocesos separados para manejar múltiples conexiones concurrentes.
*/

package TCP;

import java.net.*;
import java.io.*;

public class Servidor {

    public static void main(String args[]) {
        ServerSocket s = (ServerSocket) null;
        Socket s1;
        
        String cadena = "Tutorial de Java!";
        int longCad;
        OutputStream s1out;
        
        // Establece el servidor en el socket 4321 (espera 300 segundos)
        try {
            s = new ServerSocket(5001, 300);
        } catch (IOException e) {
            System.out.println(e);
        }
        
        // Ejecuta un bucle infinito de listen/accept
        while (true) 
        {
            try 
            {
                // Espera para aceptar una conexión
                s1 = s.accept();
                
                // Obtiene un controlador de salida asociado con el socket
                s1out = s1.getOutputStream();
                
                // Enviamos nuestro texto
                longCad = cadena.length();
                
                for (int i = 0; i < longCad; i++) 
                {
                    s1out.write((int) cadena.charAt(i));
                }
                
                // Cierra la conexión, pero no el socket del servidor
                s1.close();
            } 
            catch (IOException e) 
            {
                System.out.println(e);
            }
        }
    }
}
