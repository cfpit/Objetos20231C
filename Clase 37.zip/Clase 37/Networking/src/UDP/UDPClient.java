/*
Este código implementa un cliente UDP básico que recibe y muestra los datos enviados 
por el servidor. Ten en cuenta que este es solo un ejemplo básico y no se incluyen 
consideraciones avanzadas como el envío de paquetes o el manejo de múltiples servidores.

Se crea un DatagramSocket en el puerto 4321 y con la dirección local "localhost" 
utilizando new DatagramSocket(4321, InetAddress.getByName("localhost")). Esto 
establece el punto de entrada para la comunicación UDP en el cliente.

Se crea un DatagramPacket llamado dato con un buffer de bytes de tamaño 100. Este 
DatagramPacket se utilizará para recibir los datos del servidor.

El cliente entra en un bucle infinito para recibir DatagramPacket.

Dentro del bucle, se recibe el DatagramPacket del servidor utilizando socket.receive(dato). 
Esto espera hasta que se reciba un paquete del servidor y coloca los datos 
recibidos en el buffer del DatagramPacket.

Los datos recibidos se convierten en una cadena utilizando new String(dato.getData()) 
y se imprimen en la consola utilizando System.out.println().

El hilo actual se pausa durante 2 segundos utilizando Thread.currentThread().sleep(2000). 
Esto establece un intervalo de tiempo entre las recepciones de los paquetes.

Si se produce alguna excepción durante la recepción del DatagramPacket, se captura 
y se muestra en la consola.

Si se produce alguna excepción durante la creación del DatagramSocket, también se 
captura y se muestra en la consola.

*/

package UDP;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPClient {
    public static void main(String[] args) {
        try {
            // Crea un socket UDP
            DatagramSocket socket = new DatagramSocket();
            
            String message = "¡Hola, servidor!";
            byte[] buffer = message.getBytes();
            
            // Obtiene la dirección IP del servidor (en este caso, "localhost")
            InetAddress serverAddress = InetAddress.getByName("localhost");
            
            // Crea un DatagramPacket con los datos, la longitud y la dirección del servidor
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, serverAddress, 5001);
            
            // Envía el paquete al servidor
            socket.send(packet);
            
            // Cierra el socket
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
