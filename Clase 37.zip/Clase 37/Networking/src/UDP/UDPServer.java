/*
En los sockets TCP es necesario establecer una conexión. El servidor TCP espera 
que un cliente TCP se le conecte. Una vez hecha la conexión, se pueden enviar 
mensajes. El protocolo TCP garantiza que todos los mensajes enviados van a llegar 
bien y en el orden enviado. Sólo el cliente necesita saber dónde está el servidor 
y en qué puerto está escuchando.

Por el contrario, en los sockets UDP no se establece conexión. El servidor se 
pone a la escucha de un puerto de su ordenador. El cliente también se pone a la 
escucha de un puerto de su ordenador. En cualquier momento, cualquiera de ellos 
puede enviar un mensaje al otro. Ambos necesitan saber en qué ordenador y en qué 
puerto está escuchando el otro. Aquí el concepto de cliente y servidor está un 
poco más difuso que en el caso de TCP. Podemos considerar servidor al que espera 
un mensaje y responde. Cliente sería el que inicia el envío de mensajes. El servidor 
debería, además, estar siempre arrancado y a la escucha.

Además, en contra de TCP, el protocolo UDP sólo garantiza que si el mensaje llega, 
llega bien. No garantiza que llegue ni que lleguen en el mismo orden que se han 
enviado. Este tipo de sockets es útil para el envío más o menos masivo de 
información no crucial. Por ejemplo, enviar los datos para el refresco de gráficos 
en una pantalla.

Otra ventaja de UDP respecto a TCP, es que con UDP se puede enviar un mensaje a 
varios receptores a la vez, mientras que en TCP, al haber una conexión previa, 
sólo se puede enviar el mensaje al que está conectado al otro lado. Con UDP se 
puede, por ejemplo, enviar una sola vez los datos para que varias pantallas 
refresquen sus gráficos a la vez.

Descripción del servidor UDP:

Este código implementa un servidor UDP básico que envía periódicamente un mensaje 
"hola" al destinatario especificado. Aqui no se incluyen consideraciones avanzadas 
como la recepción de paquetes o el manejo de múltiples clientes.

Se crea un DatagramSocket en el puerto 5000 y con la dirección local "localhost" 
utilizando new DatagramSocket(5000, InetAddress.getByName("localhost")). Esto 
establece el punto de entrada para la comunicación UDP en el servidor.

Se crea un DatagramPacket llamado dato que contiene el mensaje "hola". El 
DatagramPacket se configura con la dirección "localhost" y el puerto 4000 del 
destinatario.

El servidor entra en un bucle infinito para enviar el DatagramPacket a intervalos 
regulares.

Dentro del bucle, se envía el DatagramPacket utilizando socket.send(dato). Esto 
envía el mensaje al destinatario especificado.

El hilo actual se pausa durante 2 segundos utilizando Thread.currentThread().sleep(2000). 
Esto establece un intervalo de tiempo entre los envíos de los paquetes.

Si se produce alguna excepción durante el envío del DatagramPacket, se captura y 
se muestra en la consola.

Si se produce alguna excepción durante la creación del DatagramSocket, también se 
captura y se muestra en la consola.


 */
package UDP;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServer {

    public static void main(String[] args) throws InterruptedException {
        try {
            // Crea un socket UDP en el puerto 5000
            DatagramSocket socket = new DatagramSocket(5001);

            byte[] buffer = new byte[1024];

            // Crea un DatagramPacket para recibir los datos del cliente
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

            // Espera a recibir un paquete del cliente
            socket.receive(packet);

            // Convierte los datos recibidos en una cadena y la imprime
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Mensaje recibido: " + message);

            // Cierra el socket
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
