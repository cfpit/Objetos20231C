package abstractFactory;

public interface Shape {
    void draw();
}
