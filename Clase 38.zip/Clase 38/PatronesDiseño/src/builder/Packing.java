package builder;

public interface Packing {
    public String pack();
}
