package factory;

public interface Shape {
    void draw();
}
