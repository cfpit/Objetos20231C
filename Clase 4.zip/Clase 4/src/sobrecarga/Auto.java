
package sobrecarga;

public class Auto {
    //atributos
    public String marca;
    public String color;
    public int velocidad;
    
    //constructor
    public Auto() {}
    
    //metodos
    //metodo acelerar sin sobrecarga
    public void acelerar() {
        this.velocidad += 10;
    }
    
    //metodo acelerar sobrecargado con 1 parametro
    public void acelerar(int km) {
        this.velocidad += km;
    }
    
    //metodo acelerar sobrecargado con 2 parametros
    public void acelerar(int km, boolean turbo) {
//        if (!turbo) 
//        if (turbo == false) 
        if (turbo) 
        {
            this.velocidad += km * 2;
        } 
        else 
        {
//            this.velocidad += km;
            acelerar(km);
        }
    }

    @Override
    public String toString() {
        return  "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
