package sobrecarga;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //creo un objeto de la clase Auto
        Auto a = new Auto();
        
        //le doy un estado inicial al objeto
        a.marca = "Chevy";
        a.color = "Azul";
        a.velocidad = 0;
        
        //le doy un comportamiento al objeto
        a.acelerar();//0->10
        a.acelerar();//10->20
        a.acelerar(50);//20->70
        a.acelerar(25,true);//70->120
        a.acelerar(15,false);//120->135
        
        
        //veo el estado final del objeto
        System.out.println(a.toString());
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
