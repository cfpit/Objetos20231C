package constructores;

public class Alumno {
    //atributos
    public String nombre;
    public int edad;
    public String curso;
    
    //constructor vacio
    public Alumno() {}
    
    //constructor sobrecargado con 3 parametros
    public Alumno(String nombre, int edad, String curso) {
        this.nombre = nombre;
        this.edad = edad;
        this.curso = curso;
    }
    
    //metodos
    public void inscribirse() {
        System.out.println("El alumno "+ this.nombre + 
                " se inscribio en el curso de " + this.curso);
    }
    
    public void aprobar() {
        System.out.println("El alumno "+ this.nombre + 
                " aprobo el curso de " + this.curso);
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad + ", curso=" + curso;
    }

}
