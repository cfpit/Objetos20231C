package constructores;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos de la clase Alumno
        Alumno a = new Alumno();
        Alumno b = new Alumno("Juan Perez", 24, "Java");
        
        //le damos un estado inicial al objeto a
//        System.out.println("hola".length());
        a.nombre = "Maria Garcia";
        a.edad = 24;
        a.curso = "React JS";// con hooks
        
        //comportamiento
        a.inscribirse();
        System.out.println("--------------");
        b.aprobar();
        
        //veo el estado
        System.out.println(a.toString());
        System.out.println("---------------");
        System.out.println(b);
        
        
        
        
    }
}
