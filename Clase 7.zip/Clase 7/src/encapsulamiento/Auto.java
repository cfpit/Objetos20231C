
package encapsulamiento;


public class Auto {
    //atributos
    public String marca;
    public String color;
    private int velocidad;
    
    //constructores
    //vacio
    public Auto() {}
    
    //sobrecargado
    public Auto(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
        this.velocidad = velocidad;
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 130) 
        {
            this.velocidad = velocidad;
        } 
        else 
        {
            System.out.println("Velocidad limitada!!");
            
            if (velocidad > 130) 
            {
                this.velocidad = 130;
            } 
            else 
            {
                this.velocidad = 0;
            }
        }
    }
    
    //metodos
    //acelerar sin sobrecarga
    public void acelerar() {
//        this.velocidad += 10;
        this.setVelocidad(this.velocidad + 10);
    }
    
    //acelerar sobrecargado con 1 parametro
    public void acelerar(int km) {
//        this.velocidad += km;
        this.setVelocidad(this.velocidad + km);
    }
    
    //acelerar sobrecargado con 2 parametros
    public void acelerar(int km, boolean turbo) {
//        if (turbo == true) 
        if (turbo) 
        {
//            this.velocidad += km * 2;
            this.setVelocidad(this.velocidad + km * 2);
        } 
        else 
        {
//            this.velocidad += km;
            this.setVelocidad(this.velocidad + km);
        }
    }
    
    
    //frenar sin sobrecarga
    public void frenar() {
//        this.velocidad -= 5;
        this.setVelocidad(this.velocidad - 5);
    }
    
    //frenar sobrecargado con 1 parametro
    public void frenar(int km) {
//        this.velocidad -= km;
        this.setVelocidad(-15);
    }
    
    //metodo toString
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad + '}';
    }

}
