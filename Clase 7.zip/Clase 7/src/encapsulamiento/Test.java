
package encapsulamiento;


public class Test {
    public static void main(String[] args) {
        //creo un objeto con el constructor vacio
        Auto a = new Auto();
        
        //le doy un estado inicial al objeto
        a.marca = "BMW";
        a.color = "Beige";
        a.setVelocidad(60);
        
        //comportamiento
        a.acelerar();//60 -> 70
        a.acelerar(25);//70 -> 95
        a.acelerar(15 , true);//95 -> 125
        a.acelerar(50);//limita a 130
        
        a.frenar(140);//limita a 0
        
        
        //veo el estado final
        System.out.println(a);
    }
}










