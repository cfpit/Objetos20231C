
package encapsulamiento;

import java.util.Arrays;


public class Auto {
    //atributos
    public String marca;
    private String color;
    private int velocidad;
    private String[] colores = {"blanco", "gris", "rojo", "azul"};

    //constructores
    //vacio
    public Auto() {}
    
    //sobrecargado
    public Auto(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
        this.setVelocidad(velocidad);
    }

    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 130) 
        {
            this.velocidad = velocidad;
        } 
        else 
        {
            System.out.println("Limitacion de velocidad activada");
            if (velocidad > 130) 
            {
                this.velocidad = 130;
            } 
            else 
            {
                this.velocidad = 0;
            }
        }
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        //regla de negocio
        // validar que el color es uno de los permitidos
        if (Arrays.asList(colores).contains(color.toLowerCase())) 
        {
            this.color = color.toLowerCase();
        } 
        else 
        {
            System.out.println("El color debe ser blanco, gris, rojo o azul.");
        }
    }
    
    

    //metodos
    //acelerar sin sobrecarga
    public void acelerar() {
        this.setVelocidad(this.velocidad + 10);
    }
    
    
    //acelerar sobrecargado con 1 parametro
    public void acelerar(int km) {
        this.setVelocidad(this.velocidad + km);
    }
    
    //acelerar sobrecargado con 2 parametros
    public void acelerar(int km, boolean  turbo) {
        if (turbo) 
        {
            this.setVelocidad(this.velocidad + km * 2);
        } 
        else 
        {
            this.acelerar(km);
        }
    }
    
    //frenar sin sobrecarga
    public void frenar() {
        this.setVelocidad(this.velocidad - 5);
    }
    
    //frenar sobrecargado con 1 parametro
    public void frenar(int km) {
        this.setVelocidad(this.velocidad - km);
    }
    
    //metodo toString
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad + '}';
    }
    
        
}
