
package encapsulamiento;


public class Test {
    public static void main(String[] args) {
        //creo un objeto de la clase Auto
        Auto a = new Auto();
        Auto b = new Auto("Ford", "Gris", 45000);
        
        
        //defino un estado inicial para el objeto
        a.marca = "Fiat";
        a.setColor("Beige");
        a.setVelocidad(567);
        
        //comportamiento
        a.acelerar();// 0 -> 10
        a.acelerar(35);// 10 -> 45
        a.acelerar(25,true);// 45 -> 95
        
        a.frenar();// 95 -> 90
        a.frenar(80);// 90 -> 10
        
        a.repintar("BLANco");
        
        //veo el estado final del objeto
        System.out.println(a);
        System.out.println("--------------------------------");
        System.out.println(b.toString());
        
        
        System.out.println("--------------------------------");
        
        System.out.println("velocidad final del autom a: " + a.getVelocidad() + " km./h");
        
        
        
    }
}
