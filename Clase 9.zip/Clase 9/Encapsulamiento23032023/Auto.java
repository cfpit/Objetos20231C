/*El encapsulamiento oculta el estado de los objetos para que no se le asignen 
valores invalidos.(Son privados)
El primer paso de encapsulamiento es hacer privado el atributo a encapsular
Segundo Paso, se generan los metodos publicos get y set tambien llamados getters y setters
para acceder a los atributos privados de otras clases
GET nos permite obtener el valor privado del atributo de una clase
SET nos permite establecer el valor de un atributo privado de la clase
Paso Tres definir reglas de negocio en el metodo seter para validar rangos de valores validos de un atributo encapsulado
*/
package Encapsulamiento23032023;

import java.util.Arrays;

public class Auto {
    //ATRIBUTOS
    public String marca;
    public String color;
    private int velocidad;
    private String[] colores = {"blanco","gris","rojo","azul"};
    
    //CONSTRUCTORES VACIO Y SOBRECARGADO
    public Auto() {
    }
    
    public Auto(String marca, String color, int velocidad) {
        this.marca = marca;
        this.color = color;
        this.velocidad = velocidad;
    }
    //METODOS
    
    /*public String getMarca(){
    return marca;
    }
    public void setMarca(String marca){
    this.marca = marca;
    }*/
    public int getVelocidad(){
        return velocidad;
    }
    public void setVelocidad(int velocidad){
        //REGLA DE NEGOCIO
        /*if (velocidad >=0 && velocidad<=130) {

            this.velocidad = velocidad;
        } else {
            System.out.println("Velocidad fuera de rango.");
        }*/
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 430) 
        {
            this.velocidad = velocidad;
        } 
        else 
        {
            System.out.println("Velocidad limitada!!");
            
            if (velocidad > 430) 
            {
                this.velocidad = 430;
            } 
            else 
            {
                this.velocidad = 0;
            }
        }
    }
    public String getColor(){
    return color;
    }
    public void setColor(String color){
        //x String[] colores= {"blanco","gris","rojo","azul"};
        if (Arrays.asList(colores).contains(color.toLowerCase())) {
            this.color = color.toLowerCase();
        } else {
            System.out.println("El color debe ser blanco, gris, rojo o azul");
        }
    }

    //metodo sin sobre carga
    public void acelerar() {
        //this.velocidad += 10;
        this.setVelocidad(this.velocidad + 10);
    }

    //metodo con sobrecarga con un parametro
    public void acelerar(int km){
        //this.velocidad += km;
        this.setVelocidad(this.velocidad + km);
    }
    
    //metodo con sobrecarga con un parametro
    public void acelerar(int km,boolean turbo){
        if (turbo) {
         //this.velocidad += km*2; 
         this.setVelocidad(this.velocidad + km * 2);
        } else {
            acelerar(km);//metodo con 1 parametro
        }
        
    }
    //metodo sin sobre carga
    public void frenar(){
        this.setVelocidad(this.velocidad - 5);
    }

    //metodo con sobrecarga con un parametro
    public void frenar(int km){
        this.setVelocidad( this.velocidad - km);
    }

    @Override
    public String toString() {
        return "marca = " + marca + "\ncolor = " + color + "\nvelocidad = " + velocidad;
    }
    
}
