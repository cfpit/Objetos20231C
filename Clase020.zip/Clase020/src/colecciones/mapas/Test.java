package colecciones.mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo map
//        HashMap<String,String> diccionario = new HashMap<>();// no ordena
//        LinkedHashMap<String,String> diccionario = new LinkedHashMap<>();//ordena segun el ingreso
        TreeMap<String,String> diccionario = new TreeMap<>();//ordenado segun la clave
        
        diccionario.put("rojo", "red");
        diccionario.put("verde", "green");
        diccionario.put("azul", "blue");
        diccionario.put("amarillo", "yellow");
        diccionario.put("naranja", "orange");
        diccionario.put("blanco", "white");
        diccionario.put("negro", "black");
        
        System.out.println(diccionario);
        
        System.out.println("-------------------");
        
        System.out.println("Claves: " + diccionario.keySet());
        
        System.out.println("-------------------");
        
        System.out.println("Valores: " + diccionario.values());
        
        System.out.println("-------------------");
        
        System.out.println("Traduccion de azul: " + diccionario.get("pirulo"));
        
        System.out.println("-------------------");
        
        System.out.println("Traduccion de gris: " + diccionario.getOrDefault("gris", "No existe traduccion"));
        
        
        
        
    }
}
