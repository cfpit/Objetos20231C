package generics;

public class Test {
    public static void main(String[] args) {
        //creo 3 objetos de la clase generica
        Generica<Integer> g = new Generica<>();
        Generica<String> g2 = new Generica<>();
        Generica<Persona> g3 = new Generica<>();
        
        //comportamiento
        g.agregar(25);
        g.agregar(30);
        g.agregar(20);
        g.agregar(40);
        
        System.out.println(g.obtener(1));//30
        
        g.eliminar(40);
        
        g.listar();
        
        //comportamiento
        g2.agregar("Juan");
        g2.agregar("Maria");
        g2.agregar("Luis");
        g2.agregar("Ana");
        
        System.out.println(g2.obtener(1));//Maria
        
        g2.eliminar("Ana");
        
        g2.listar();
        
        //comportamiento
        g3.agregar(new Persona("Juan", 25));
        g3.agregar(new Persona("Maria", 30));
        g3.agregar(new Persona("Luis", 20));
        g3.agregar(new Persona("Ana", 40));
        
        System.out.println(g3.obtener(1));
        
        g3.eliminar(g3.obtener(2));//eliminamos a Luis
        
        g3.listar();
    }
}


