package relacion1a1;

public class Auto {
    private String marca;
    private String patente;
    
    /*
        Relacion 1 a 1
        Se da cuando cada objeto de la clase Auto
        se relaciona con un solo objeto de la clase Motor
    */
    private Motor motor; 

    public Auto() {
    }

    public Auto(String marca, String patente, Motor motor) {
        this.marca = marca;
        this.patente = patente;
        this.motor = motor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", patente=" + patente + ", motor=" + motor + '}';
    }
}
