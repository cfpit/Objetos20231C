package relacion1a1;

public class Motor {
    private String nroMotor;
    private String cilindrada;

    public Motor() {
    }

    public Motor(String nroMotor, String cilindrada) {
        this.nroMotor = nroMotor;
        this.cilindrada = cilindrada;
    }

    public String getNroMotor() {
        return nroMotor;
    }

    public void setNroMotor(String nroMotor) {
        this.nroMotor = nroMotor;
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "nroMotor=" + nroMotor + ", cilindrada=" + cilindrada;
    }
}
