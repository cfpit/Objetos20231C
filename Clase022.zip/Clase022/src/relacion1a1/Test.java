package relacion1a1;

public class Test {
    public static void main(String[] args) {
        Motor m = new Motor("1234", "1600");
        
        Auto a = new Auto("Chevrolet", "ABC123", m);
        
        System.out.println(a);
    }
}
