package relacion1aN;

public class Auto {
    private String marca;
    private String color;

    public Auto() {
    }

    public Auto(String marca, String color) {
        this.marca = marca;
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color;
    }
}
