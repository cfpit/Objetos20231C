package relacion1aN;

import java.util.ArrayList;
import java.util.List;

public class Concesionaria {
    private String nombre;
    
    /*
        Relacion 1 a N: un objeto de la clase Concesionaria
        posee una coleccion de objetos de la clase Auto
    */
    private List<Auto> autos;

    public Concesionaria() {
    }

    public Concesionaria(String nombre) {
        this.nombre = nombre;
        
        //asigno una coleccion vacia al atributo autos
        this.autos = new ArrayList<>();
    }
    
    //delegado
    public boolean agregarAuto(Auto e) {
        return autos.add(e);
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Auto> getAutos() {
        return autos;
    }

    public void setAutos(List<Auto> autos) {
        this.autos = autos;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", autos=" + autos;
    }
}





