package abmc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Alumno {
    private String nombre;
    private int edad;

    public Alumno() {}

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
    
    //metodos ABMC
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion a la BD
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la consulta sql
        String consulta = "select * from alumnos";
        
        //creo una sentencia
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la sentencia y guardo el resultado
        //en un objeto de tipo ResultSet
        ResultSet unResultado = unaSentencia.executeQuery(consulta);
        
        //recorro y muestro el resultado con un bucle 
        while (unResultado.next()) 
        {
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("--------------------------------");
        }
        
        //cierro la sentencia y la conexion
        unaSentencia.close();
        unaConexion.close();
    }
    
    
}
