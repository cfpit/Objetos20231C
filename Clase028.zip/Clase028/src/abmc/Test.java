package abmc;

import java.sql.SQLException;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Conexion.obtenerConexion();
        
        Alumno.consultarTodos();
    }
}
