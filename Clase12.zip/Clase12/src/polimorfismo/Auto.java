
package polimorfismo;

import java.util.Arrays;


public class Auto {
    //atributos
    private String marca;
    protected int velocidad;
    
    //constructores
    public Auto() {}

    public Auto(String marca, int velocidad) {
        this.setMarca(marca);
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        //regla de negocio
        if (velocidad >= 0 && velocidad <= 130) 
        {
            this.velocidad = velocidad;
        } 
        else 
        {
            System.out.println("velocidad fuera de rango");
        }
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        //regla de negocio
        String [] marcas = {"ford","ferrari","honda","chevrolet","fiat","renault"};
        
        if (Arrays.asList(marcas).contains(marca.toLowerCase())) 
        {
            this.marca = marca.toLowerCase();
        } 
        else 
        {
            System.out.println("la marca no es admitida");
        }
    }
    
    //metodos
    public void acelerar() {
        this.setVelocidad(this.velocidad + 10);
    }

    @Override
    public String toString() {
        return "marca=" + this.marca + ", velocidad=" + this.velocidad;
    }
}
