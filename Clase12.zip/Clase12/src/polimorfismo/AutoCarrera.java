
package polimorfismo;


public class AutoCarrera extends Auto{
    //atributos
    private String tipoAleron;

    //constructores
    public AutoCarrera() {}

    public AutoCarrera(String marca, int velocidad, String tipoAleron) {
        //llamada al constructor del padre(clase Auto)
        super(marca, velocidad);
        
        this.setTipoAleron(tipoAleron);
    }

    //getters y setters
    public String getTipoAleron() {
        return tipoAleron;
    }

    public void setTipoAleron(String tipoAleron) {
        this.tipoAleron = tipoAleron;
    }
    
    //metodos

    //sobreescribimos el cuerpo(no la firma) del metodo
    //acelerar heredado desde la clase padre(Auto)
    @Override
    public void acelerar() {
        this.setVelocidad(this.velocidad + 50);
    }
    
    @Override
    public String toString() {
        return  super.toString() + " tipoAleron=" + tipoAleron;
    }
}
