
package polimorfismo;


public class Test {
    public static void main(String[] args) {
        //creo 2 autos
        Auto a = new Auto("FORD", 0);
        AutoCarrera ac = new AutoCarrera("Ferrari", 0, "titanio");
        
        //comportamiento
        a.acelerar();// 0 -> 10
        ac.acelerar();// 0 --> 50
        
        //estado final de los autos
        System.out.println("Auto: \n" + a);
        System.out.println("Auto Carrera: \n" + ac.toString());        
    }
}
