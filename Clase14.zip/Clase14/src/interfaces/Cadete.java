
package interfaces;


//public class Cadete extends otraClase implements Empleado, otraInterface{
public class Cadete implements Empleado{
    //atributos
    private String nombre;
    private double valorHora;
    private int horasTrabajadas;
    
    //constructores
    public Cadete() {}

    public Cadete(String nombre, double valorHora, int horasTrabajadas) {
        this.setNombre(nombre);
        this.setValorHora(valorHora);
        this.setHorasTrabajadas(horasTrabajadas);
    }

    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }
    
    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }
    
    //metodos
    //implemento el metodo abstracto de la interface Empleado
    @Override
    public void calcularSueldo() {
        System.out.println("Sueldo Cadete: \n"+
                    this.valorHora * this.horasTrabajadas + " U$s");
    }

    @Override
    public String toString() {
        return "Cadete{" + "nombre=" + nombre + ", valorHora=" + valorHora + ", horasTrabajadas=" + horasTrabajadas + '}';
    }
}
