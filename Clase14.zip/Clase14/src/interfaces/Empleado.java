
package interfaces;

public interface Empleado {
    //contiene un contrato
    //contrato: es un conjunto de metodos abstractos
    //q indican el comportamiento q van a tener
    //las clases q la implementen pero no el COMO
    //lo van a implementar
    
//    public void metodo1();
//    public void metodo2();
//    public void metodo3();
    
    public void calcularSueldo();
}
