
package interfaces;

public class Gerente implements Empleado{
    
    //atributos
    private String nombre;
    private double sueldoBase;
    private int antiguedad;

    //constructores
    public Gerente() {}

    public Gerente(String nombre, double sueldoBase, int antiguedad) {
        this.setAntiguedad(antiguedad);
        this.setNombre(nombre);
        this.setSueldoBase(sueldoBase);
    }

    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public double getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(double sueldoBase) {
        this.sueldoBase = sueldoBase;
    }
    
    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }
    
    //metodos
    //implemento el metodo abstracto de la interface Empleado

    @Override
    public void calcularSueldo() {
        System.out.println("Sueldo Gerente: \n"+
                (sueldoBase + sueldoBase * antiguedad * 0.1 )+ " U$s");
    }
    
    @Override
    public String toString() {
        return "Gerente{" + "nombre=" + nombre + ", sueldoBase=" + sueldoBase + ", antiguedad=" + antiguedad + '}';
    }
}
