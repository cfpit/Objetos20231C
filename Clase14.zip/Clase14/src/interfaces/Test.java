
package interfaces;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos
        Gerente g = new Gerente("Juan Perez", 3000, 15);
        Cadete c = new Cadete("Pedro Picapiedra", 5, 160);
        
        //comportamiento
        g.calcularSueldo();
        c.calcularSueldo();
        
       
    }
}
