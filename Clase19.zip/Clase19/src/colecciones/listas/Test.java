package colecciones.listas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo lista
//        List personas = new ArrayList();//coleccion no tipada
        List<Persona> personas = new ArrayList<>();//coleccion tipada
        
        //creo objetos de la clase Persona y los agrego a la lista
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Luis", 20);
        Persona p4 = new Persona("Ana", 40);
        
        personas.add(p1);
        personas.add(p2);
        personas.add(p3);
        personas.add(p4);
        
        //agrego un objeto anonino(sin referencia en la RAM)
        personas.add(new Persona("Carlos", 50));
        
        System.out.println("Contenido de la lista: " +  personas);
        
        System.out.println("-----------------------------");
        
        System.out.println("Recorro la lista con un for");//forl
        
        for (int i = 0; i < personas.size(); i++) {
            Persona unaPersona = personas.get(i);
            
            if (unaPersona.getEdad() >= 30 && unaPersona.getEdad() <= 40) 
            {
                System.out.println(unaPersona);
            }
        }
        
        System.out.println("Recorro la lista con un foreach");//fore
        
        for (Persona unaPersona : personas) {
            if ("m".equalsIgnoreCase(String.valueOf(unaPersona.getNombre().charAt(0)))) {
                System.out.println(unaPersona);
            }
        }
        
        
        System.out.println("Recorro con un patron de diseño Iterator");//whileit
        
        //creo un iterador para recorrer la lista
        Iterator it = personas.iterator();
        
        //recorro la lista
        while (it.hasNext()) {
            Object unaPersona = it.next();
            System.out.println(unaPersona);
        }
        
    }
}





