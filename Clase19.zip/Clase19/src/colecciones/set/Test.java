package colecciones.set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo set
//        HashSet<Integer> edades = new HashSet<>();//sin orden pero + eficiente
//        LinkedHashSet<Integer> edades = new LinkedHashSet<>();//ordenado segun el ingreso
        TreeSet<Integer> edades = new TreeSet<>();//ordenado de menor a mayor
        
        //agrego objetos al set
        edades.add(25);
        edades.add(30);
        edades.add(20);
        edades.add(40);
        edades.add(40);//no lo agrega por estar duplicado(por ser un set)
        
        //contenido de la coleccion
        System.out.println(edades);
    }
}
