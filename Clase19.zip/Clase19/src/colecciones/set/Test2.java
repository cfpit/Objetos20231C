package colecciones.set;

import java.util.TreeSet;

public class Test2 {
    public static void main(String[] args) {
        //creo una coleccion de tipo TreeSet
        TreeSet<Persona> personas = new TreeSet<>();
        
        //agrego objetos al set
        personas.add(new Persona("Juan", 25));
        personas.add(new Persona("Maria", 30));
        personas.add(new Persona("Luis", 20));
        personas.add(new Persona("Ana", 40));
        
        //contenido de la coleccion
        System.out.println(personas);
    
    }
}
