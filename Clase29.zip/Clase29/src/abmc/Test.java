package abmc;

import java.sql.SQLException;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Scanner lector = new Scanner(System.in);
        
        Conexion.obtenerConexion();
        
        System.out.println("Consultar todos los alumnos");
        Alumno.consultarTodos();
        
        System.out.println("Consultar por un alumno");
        System.out.println("Ingresa el nombre del alumno: ");
        Alumno.consultarUno(lector.next());
        
//        System.out.println("Insercion");
//        System.out.println("nombre: ");
//        System.out.println("edad: ");
//        Alumno a = new Alumno(lector.next(), lector.nextInt());
//        Alumno.insertar(a);
//        Alumno.consultarTodos();
        
//        System.out.println("Actualizacion");
//        System.out.println("nombre: ");
//        System.out.println("edad: ");
//        Alumno a = new Alumno(lector.next(), lector.nextInt());
//        Alumno.actualizar(a);
//        Alumno.consultarTodos();
        
//        System.out.println("Eliminacion");
//        System.out.println("nombre: ");
//        Alumno.eliminar(lector.next());
//        Alumno.consultarTodos();
        
        
    }
}
