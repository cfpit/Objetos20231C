package copiador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            File archivoOrigen = new File("src/copiador/origen.txt");
            File archivoDestino = new File("src/copiador/destino.txt");
            
            BufferedReader streamLectura = new BufferedReader(new FileReader(archivoOrigen));
            BufferedWriter streamEscritura = new BufferedWriter(new FileWriter(archivoDestino));

            //algoritmo de copia
            String unaLinea;//almacena la linea leida por el stream de lectura

            //bucle de copia
            //mientras haya lineas por leer de origen.txt
            while ((unaLinea = streamLectura.readLine()) != null) {
                streamEscritura.write(unaLinea);
                streamEscritura.newLine();
            }

            //cierro los streams
            streamLectura.close();
            streamEscritura.close();
            
            System.out.println("El archivo se ha copiado...");
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo");
        } catch (IOException e) {
            System.out.println("Error de lectura o escritura");
        }
                
    }
}
