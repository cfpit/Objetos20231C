package escritor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        try {
            //creo un objeto File q tendra la ruta del archivo a escribir
            File archivo = new File("src/escritor/destino.txt");

            //creo el stream de escritura
            BufferedWriter streamEscritura = new BufferedWriter(new FileWriter(archivo));

            //defino el contenido a escribir
            String linea1 = "Esta es la linea 1";
            String linea2 = "Esta es la linea 2";
            String linea3 = "Esta es la linea 3";

            //escribo mediante el stream...
            //si el archivo no existe, lo crea y escribe en el.
            //si el archivo existe, lo sobreescribe
            streamEscritura.write(linea1);
            streamEscritura.newLine();//salto de linea
            
            streamEscritura.write(linea2);
            streamEscritura.newLine();
            
            streamEscritura.write(linea3);
            streamEscritura.newLine();

            //cierro el stream
            streamEscritura.close();
            
            System.out.println("Archivo creado o sobreescrito...");
        } catch (IOException e) {
            System.out.println("Error de escritura");
        }
    }
}
