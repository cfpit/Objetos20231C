package lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            //creo un objeto de tipo File(java.io) que guardara
            //la ruta(path) del archivo
//        File archivo = new File("src\\lector\\fuente.txt");
            File archivo = new File("src/lector/fuente.txt");

            //creo un stream de lectura q lee el archivo fuente.txt de a lineas enteras
            BufferedReader streamLectura = new BufferedReader(new FileReader(archivo));

            //algoritmo de lectura
            String lineaLeida = "";//alamacena una linea entera leida por el stream
            boolean eof = false;//eof = end of file(flag)

            //bucle de lectura
            while (!eof) {
                lineaLeida = streamLectura.readLine();
                
                if (lineaLeida != null) {
                    System.out.println(lineaLeida);
                } else {
                    eof = true;
                }
            }

            //cierro el stream
            streamLectura.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo");
        } catch (IOException e) {
            System.out.println("Error de lectura");
        } catch (Exception e) {
            System.out.println("Se produjo un error");
        }
        
    }
}
