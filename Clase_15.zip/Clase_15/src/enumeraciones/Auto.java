package enumeraciones;

public class Auto {
    //atributos
    private String marca;   
    private String color;
    
    //constructores
    public Auto() {}

    public Auto(String marca, String color) {
        this.setMarca(marca);
        this.setColor(color);
    }

    //getters y setters
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    //metodos
    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color;
    }
}
