
package enumeraciones;

public enum Colores {
        BLANCO, NEGRO, AZUL,
        ROJO, VERDE, GRIS,
        PLATEADO, DORADO
}









