package enumeraciones;

public class Test {
    public static void main(String[] args) {
        //creo un auto
        Auto a = new Auto("Ford", String.valueOf(Colores.PLATEADO).toLowerCase());
        
        //estado del auto
        System.out.println(a);
    }
}
