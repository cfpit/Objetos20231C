package palabraFinal;


import java.util.Arrays;

//public final class Auto {
public class Auto {
    //atributos
    private String marca;   
    private String color;
    
    //declaro el atributo constante
    public final int VELMAX = 200;
    
    //constructores
    public Auto() {}

    public Auto(String marca, String color) {
        this.setMarca(marca);
        this.setColor(color);
    }

    //getters y setters
    public String getColor() {
        return color;
    }

    public final void setColor(String color) {
        //regla de negocio
        String [] colores = {"Gris","Rojo","Plateado","Azul","Blanco","Negro"};
        if (Arrays.asList(colores).contains(color.toLowerCase())) 
        {
            this.color = color;
        } 
        else 
        {
            System.out.println("Color no permitido");
        }
    }
    
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    //metodos
    //lo hago final para que no sea sobrescrito
    //en caso de herencia x ninguna clase hija(es 
    //decir, q no se le pueda aplicar polimorfismo)
    public final void repintar(String nuevoColor) {
        this.setColor(nuevoColor);
    }
    
    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color;
    }
}
