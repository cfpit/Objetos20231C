package palabraStatic;

import palabraFinal.*;

public class AutoCarrera extends Auto{
    //atributos
    private String tipoDeAleron;
    
    //constructores
    public AutoCarrera() {}
    
    public AutoCarrera(String tipoDeAleron, String marca, String color) {
        super(marca, color);
        this.setTipoDeAleron(tipoDeAleron);
    }

    //getters y setters
    public String getTipoDeAleron() {
        return tipoDeAleron;
    }

    public void setTipoDeAleron(String tipoDeAleron) {
        this.tipoDeAleron = tipoDeAleron;
    }
    
    //intento en vano sobrescribir el metodo repintar heredado
    //dsd la clase padre(Auto)
//    public void repintar(String nuevoColor) {
//        System.out.println("Otra cosa");
//    }

}
