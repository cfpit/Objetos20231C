package palabraStatic;

import palabraFinal.*;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto("Chevrolet", "Azul");
        
        System.out.println("Velocidad maxima = " + a.VELMAX + " km./h.");
        
        //intento modificar la constante
//        a.VELMAX = 300;//no se puede modificar el valor de una constante

    //intento acceder a el atributo estatico velocidad
    //a traves del objeto
    a.velocidad = 75;
        System.out.println
                        (
                                "velocidad del auto a: " + a.velocidad + " km./h."
                        );
    //si es posible acceder    
    

    //intento acceder a el atributo estatico velocidad
    //a traves de la clase sin instanciar ningun objeto
    Auto.velocidad = 110;
        System.out.println
                        (
                                "velocidad del auto a: " + Auto.velocidad + " km./h."
                        );
    //si es posible acceder    
        
        
    }
}
