package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de objetos de tipo Cola
        Queue cola = new LinkedList();
        
        //agrego objetos en la cola
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Luis");
        cola.add("Carlos");
        
        System.out.println(cola);
        
        System.out.println("Tamaño de la cola: "+ cola.size());
        
        System.out.println("1er elemento a salir: "+ cola.peek());
        
        System.out.println("1er elemento que sale: "+ cola.poll());
        
        System.out.println("Nuevo contenido de la cola: "+ cola);
        
        
    }
}
