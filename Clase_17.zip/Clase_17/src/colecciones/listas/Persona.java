package colecciones.listas;

public class Persona {
    //atributos
    private String nombre;
    private int edad;
    
    //constructores
    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    //getters y setters
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    //metodos

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
}
