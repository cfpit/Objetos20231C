

package colecciones.listas;

import java.util.ArrayList;
import java.util.List;


public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo Lista
        List personas = new ArrayList();
        
        //creo objetos de la clase Persona
        //mediante objetos anonimos y los guardo
        //en la lista
        personas.add(new Persona("Juan Perez", 25));
        personas.add(new Persona("Maria Garcia", 30));
        personas.add(new Persona("Luis Lopez", 20));
        personas.add(new Persona("Carlos Rios", 40));
        
        
        System.out.println("Contenido de la lista: ");
        System.out.println(personas);
    }
}






