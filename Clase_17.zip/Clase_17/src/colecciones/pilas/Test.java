package colecciones.pilas;

import java.util.Stack;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de objetos de tipo Pila
        Stack pila = new Stack();//LIFO
        
        //agrego objetos de la clase String
        pila.push("Juan");
        pila.push("Maria");
        pila.push("Luis");
        pila.push("Carlos");
        
        System.out.println("Contenido de la pila: "+ pila);
        
        System.out.println("Tamaño de la pila: "+ pila.size());
        
        System.out.println("1er elemento a salir: "+ pila.peek());
        
        System.out.println("1er elemento que sale: "+ pila.pop());
        
        System.out.println("Nuevo contenido de la pila: "+ pila);
        
        System.out.println("pila vacia?: " +  pila.isEmpty());
    }
}




