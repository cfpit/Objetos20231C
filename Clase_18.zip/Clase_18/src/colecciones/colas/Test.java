package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo cola
        Queue<String> cola = new LinkedList<>();
        
        //agrego objetos en la coleccion de tipo cola(fifo)
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Luis");
        cola.add("Ana");
        
        System.out.println("Contenido de la cola: " + cola);
        
        System.out.println("Tamaño de la cola: " + cola.size());
        
        System.out.println("1er elemento a salir: " + cola.peek());
        
        System.out.println("saco un elemento: " + cola.poll());
        
        System.out.println("Nuevo contenido de la cola: " + cola);
        
        
        
        
        
        
        
    }
}
