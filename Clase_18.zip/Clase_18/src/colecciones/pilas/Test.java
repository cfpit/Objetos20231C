package colecciones.pilas;

import java.util.Iterator;
import java.util.Stack;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo pila
//        Stack<Integer> pila = new Stack<Integer>();//tipada
        Stack pila = new Stack();//coleccion no tipada
        
        //pusheo objetos de tipo Integer y String en la pila
        pila.push(23);
        pila.push(45);
        pila.push(17);
        pila.push(30);
        pila.push("Juan");
        pila.push("Maria");
        pila.push("Luis");
        
        pila.push("Ana");
        
        System.out.println("Contenido de la pila: " + pila);
        
        System.out.println("Tamaño de la pila: " + pila.size());
        
        System.out.println("1er elemento a salir: " + pila.peek());
        
        System.out.println("saco un elemento: " + pila.pop());
        
        System.out.println("Nuevo contenido de la pila: " + pila);
        
        if (pila.isEmpty())System.out.println("Pila vacia");
        else System.out.println("Pila NO vacia");
        
        System.out.println("Valor de la posicion 4: " + pila.get(4));
        
        //elimino el 1er elemento de la pila
        pila.remove(0);
        
        System.out.println("Nuevo contenido de la pila: " + pila);
        
        //recorro la coleccion
        //forl --> recorre con for
        //fore --> recorre con foreach
        //whileit --> recorre con patron de diseño Iterator
        for (Object elemento : pila) {
            System.out.println(elemento);
        }
        
        System.out.println("----------------");
        
        for (int i = 0; i < pila.size(); i++) {
            Object elemento = pila.get(i);
            System.out.println(elemento);
        }
        
        System.out.println("----------------");
        
     Iterator it = pila.iterator();
     
        while (it.hasNext()) {
            Object elemento = it.next();
            System.out.println(elemento);
        }
        
        
        
        
        
        
        
    }
}
