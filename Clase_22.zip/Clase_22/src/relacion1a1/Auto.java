package relacion1a1;

public class Auto {
    private String marca;
    private String patente;
    private Motor motor;

    public Auto() {
    }

    public Auto(String marca, String patente, Motor motor) {
        this.marca = marca;
        this.patente = patente;
        this.motor = motor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public Motor getMotor() {
        return motor;
    }

    public void setMotor(Motor motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", patente=" + patente + ", motor=" + motor;
    }
}

