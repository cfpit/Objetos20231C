package relacion1a1;

public class Motor {
    private int nroMotor;
    private int cilindrada;

    public Motor() {
    }

    public Motor(int nroMotor, int cilindrada) {
        this.setNroMotor(nroMotor);
        this.setCilindrada(cilindrada);
    }

    public int getNroMotor() {
        return nroMotor;
    }

    public void setNroMotor(int nroMotor) {
        this.nroMotor = nroMotor;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "nroMotor=" + nroMotor + ", cilindrada=" + cilindrada;
    }
}
