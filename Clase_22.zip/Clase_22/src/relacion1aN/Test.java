package relacion1aN;

public class Test {
    public static void main(String[] args) {
        Concesionaria c = new Concesionaria("Del Oeste SRL");
        
        Auto a1 = new Auto("Ford", "Gris");
        Auto a2 = new Auto("Chevrolet", "Azul");
        Auto a3 = new Auto("Renault", "Rojo");
        Auto a4 = new Auto("Peugeot", "Blanco");
        
        c.agregarAuto(a1);
        c.agregarAuto(a2);
        c.agregarAuto(a3);
        c.agregarAuto(a4);
        
        System.out.println(c);
    }
}
